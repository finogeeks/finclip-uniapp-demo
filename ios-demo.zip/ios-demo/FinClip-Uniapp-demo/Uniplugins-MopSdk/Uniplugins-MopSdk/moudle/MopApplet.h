//
//  MopApplet.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//

#ifndef MopApplet_h
#define MopApplet_h
#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

#import "DCUniModule.h"
#import "MopUtils.h"
#import "MopLifeCycleDelegate.h"

@interface MopApplet : NSObject
    
+ (instancetype)shareInstance;

- (void)setAppletLifecycleCallback:(UniModuleKeepAliveCallback)onInitComplete onOpen:(UniModuleKeepAliveCallback)onOpen
    onOpenFailure:(UniModuleKeepAliveCallback)onOpenFailure
    onInActive:(UniModuleKeepAliveCallback)onInActive
    onActive:(UniModuleKeepAliveCallback)onActive
    onClose:(UniModuleKeepAliveCallback)onClose
    onDestroy:(UniModuleKeepAliveCallback)onDestroy;

- (void)openApplet:(NSDictionary *)options onSuccess:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback)onProgress;

- (void)openAppletByQrcode:(NSDictionary *)options onSuccess:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback)onProgress;

- (void)searchApplets:(NSDictionary *)options onSuccess:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback)onProgress;
- (void) downloadApplets: (NSDictionary *) options onSuccess:(UniModuleKeepAliveCallback) onSuccess
    onFail:(UniModuleKeepAliveCallback)  onFail;
- (void) captureAppletPicture: (NSString *) appId
    snapShotWholePage:(BOOL *) snapShotWholePage
    onSuccess:(UniModuleKeepAliveCallback) onSuccess
    onFail:(UniModuleKeepAliveCallback)  onFail;

- (void) moveMiniProgramToFront:(NSString *) appId;
- (void) moveAppToFront;

- (void) currentAppletId:(UniModuleKeepAliveCallback) onCallback;
- (void) currentApplet: (UniModuleKeepAliveCallback) onCallback;


- (void) getUsedApplet:(NSString *) appId onCallback:(UniModuleKeepAliveCallback) onCallback;
- (void) getUsedApplets: (UniModuleKeepAliveCallback) onCallback;
- (void) isUsedApplet:(NSString *) appId onCallback:(UniModuleKeepAliveCallback) onCallback;

- (void)closeApplet:(NSString *)appId;
- (void)closeApplets;
- (void)finishRunningApplet:(NSString *)appId;
- (void)finishRunningApplets;
- (void)clearApplet:(NSString *) appId;
- (void)clearApplets;

@end

#endif /* MopApplet_h */
