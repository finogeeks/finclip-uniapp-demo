//
//  MopExtension.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//
#import "MopExtension.h"

@implementation MopExtension

static MopExtension *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopExtension alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

- (void)registerExtensionApi:(NSString *) name callback:(UniModuleKeepAliveCallback) callback {
    [self unRegisterExtensionApi:name];
    
    [[FATClient sharedClient] registerExtensionApi:name handler:^(FATAppletInfo *appletInfo, id param, FATExtensionApiCallback extensionCallback) {
        NSString *uuid = [MopCallbackUtils addCallback:extensionCallback];
        callback(@{@"uuid":uuid,@"event":name,@"appId":appletInfo.appId,@"params":param}, YES);
    }];
}

- (void)unRegisterExtensionApi:(NSString *) name {
}

- (void)registerWebExtensionApi:(NSString *) name callback:(UniModuleKeepAliveCallback)callback {
    [self unRegisterWebExtensionApi:name];
    
    [[FATClient sharedClient] fat_registerWebApi:name handler:^(FATAppletInfo *appletInfo, id param, FATExtensionApiCallback extensionCallback) {
            NSString *uuid = [MopCallbackUtils addCallback:extensionCallback];
            callback(@{@"uuid":uuid,@"event":name,@"appId":appletInfo.appId,@"params":param}, YES);
    }];
}

- (void)unRegisterWebExtensionApi:(NSString *) name{
}

- (void)onSuccess:(NSString *) uuid options:(NSDictionary *)options {
    FATExtensionApiCallback extensionCallback = [MopCallbackUtils getCallback:uuid];
    if (extensionCallback) {
        extensionCallback(FATExtensionCodeSuccess,options);
    }
    [MopCallbackUtils removeCallback:uuid];
}

- (void)onFail:(NSString *) uuid options:(NSDictionary *)options {
    FATExtensionApiCallback extensionCallback = [MopCallbackUtils getCallback:uuid];
    if (extensionCallback) {
        extensionCallback(FATExtensionCodeFailure,options);
    }
    [MopCallbackUtils removeCallback:uuid];
}

@end

