//
//  MopDelegate.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//

#ifndef MopDelegate_h
#define MopDelegate_h

#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

#import "DCUniModule.h"
#import "MopButtonOpenTypeDelegate.h"
#import "MopShareDelegate.h"
#import "MopConfigurationDelegate.h"
#import "MopMoreMenuDelegate.h"
#import "MopCustomMenuModel.h"

@interface MopDelegate : NSObject
 
+ (instancetype)shareInstance;

- (void)initDelegate;
-(void) setChooseAvatar:(NSString * ) chooseAvatar;
-(void) setPhoneNumber:(NSString * ) phoneNumber;
-(void) setUserInfo:(NSDictionary * ) userInfo;
-(void) setOpenTypeShareAppMessage: (UniModuleKeepAliveCallback) shareCallback;
-(void) setShareAppMessage: (UniModuleKeepAliveCallback) shareCallback;
-(void) setGrayAppletVersionConfigs:(NSArray *) grayExtensionArray;
-(void) setRegisteredMoreMenuItems:(NSArray *) grayExtensionArray onRegisteredMoreMenuItemClicked:(UniModuleKeepAliveCallback) onRegisteredMoreMenuItemClicked;
-(void) setNavigationBarCloseButtonClicked:(UniModuleKeepAliveCallback) closeCallback;
@end

#endif /* MopDelegate_h */
