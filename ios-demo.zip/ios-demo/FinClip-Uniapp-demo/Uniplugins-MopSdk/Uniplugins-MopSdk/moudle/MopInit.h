//
//  MopInit.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//

#ifndef MopInit_h
#define MopInit_h

#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

#import "DCUniModule.h"
#import "MopUtils.h"

@interface MopInit : NSObject
 
+ (instancetype)shareInstance;

- (BOOL)init:(NSDictionary *)config success:(UniModuleKeepAliveCallback)success fail:(UniModuleKeepAliveCallback)fail;

@end


#endif /* MopInit_h */
