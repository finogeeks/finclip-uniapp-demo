//
//  MopDelegate.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//
#import "MopDelegate.h"

@implementation MopDelegate

static MopDelegate *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopDelegate alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

- (void) initDelegate {
    [FATClient sharedClient].buttonOpenTypeDelegate = [MopButtonOpenTypeDelegate shareInstance];
    [FATClient sharedClient].shareItemDelegate = [MopShareDelegate shareInstance];
    [FATClient sharedClient].configurationDelegate = [MopConfigurationDelegate shareInstance];
    [FATClient sharedClient].moreMenuDelegate = [MopMoreMenuDelegate shareInstance];
}

-(void) setChooseAvatar:(NSString * ) chooseAvatar {
    [[MopButtonOpenTypeDelegate shareInstance]setChooseAvatar:chooseAvatar];
}

-(void) setPhoneNumber:(NSString * ) phoneNumber {
    [[MopButtonOpenTypeDelegate shareInstance]setPhoneNumber:phoneNumber];
}

-(void) setUserInfo:(NSDictionary * ) userInfo {
    [[MopButtonOpenTypeDelegate shareInstance]setUserInfo:userInfo];
}

-(void) setOpenTypeShareAppMessage: (UniModuleKeepAliveCallback) shareCallback{
    [[MopButtonOpenTypeDelegate shareInstance]setOpenTypeShareAppMessage:shareCallback];
}

-(void) setShareAppMessage: (UniModuleKeepAliveCallback) shareCallback{
    [[MopShareDelegate shareInstance] setShareAppMessage:shareCallback];
}

- (void) setGrayAppletVersionConfigs:(NSArray *) grayExtensionArray {
    NSMutableDictionary *grayExtension = [[NSMutableDictionary alloc] init];
    //常用的一种遍历方法
    NSUInteger len = grayExtensionArray.count;
    for(NSUInteger i=0; i<len; i++){
       NSDictionary *dic   = grayExtensionArray[i];
        grayExtension[dic[@"key"]] = dic[@"value"];
    }
    [[MopConfigurationDelegate shareInstance] setGrayAppletVersionConfigs:grayExtension];
}

-(void) setRegisteredMoreMenuItems:(NSArray *) menuItemArrays onRegisteredMoreMenuItemClicked:(UniModuleKeepAliveCallback) onRegisteredMoreMenuItemClicked {
    NSMutableArray<id<FATAppletMenuProtocol>> *menuItems = [[NSMutableArray<id<FATAppletMenuProtocol>> alloc]init];
    //常用的一种遍历方法
    NSUInteger len = menuItemArrays.count;
    for(NSUInteger i=0; i<len; i++){
       NSDictionary *dic   = menuItemArrays[i];
       MopCustomMenuModel *model = [[MopCustomMenuModel alloc] init];
       model.menuId = dic[@"id"];
       model.menuTitle =  dic[@"title"];
       model.menuIconUrl = dic[@"image"];
       model.menuDarkIconUrl = dic[@"image"];
       if ([@"ON_MINI_PROGRAM" isEqualToString: dic[@"type"]]) {
           model.menuType = FATAppletMenuStyleOnMiniProgram;
       } else {
           model.menuType = FATAppletMenuStyleCommon;
       }
       [menuItems addObject:model];
    }
    [[MopMoreMenuDelegate shareInstance] setRegisteredMoreMenuItems:menuItems onRegisteredMoreMenuItemClicked:onRegisteredMoreMenuItemClicked];
}

-(void) setNavigationBarCloseButtonClicked:(UniModuleKeepAliveCallback) closeCallback {
    [[MopMoreMenuDelegate shareInstance] setNavigationBarCloseButtonClicked:closeCallback];
}

@end
