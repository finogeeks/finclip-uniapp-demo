//
//  MopEvent.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//
#import "MopEvent.h"

@implementation MopEvent

static MopEvent *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopEvent alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

- (void)sendCustomEvent:(NSString *) appId options:(NSDictionary *) options {
    [[FATClient sharedClient].nativeViewManager sendCustomEventWithDetail:options applet:appId completion:^(id result, NSError *error) {
    }];
}

- (void)sendCustomEventToAll:(NSDictionary *) options{
    [[FATClient sharedClient].nativeViewManager sendCustomEventWithDetail:options completion:^(id result, NSError *error) {
    }];
}

@end
