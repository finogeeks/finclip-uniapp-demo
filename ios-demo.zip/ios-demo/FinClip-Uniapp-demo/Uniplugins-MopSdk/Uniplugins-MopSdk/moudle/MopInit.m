//
//  MopInit.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//
#import "MopInit.h"

@implementation MopInit

static MopInit *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopInit alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}


/**
 * 初始化SDK
 * @param config js 端调用方法时传递的参数
 * @param success 回调方法，回传参数给 js 端
 * @param fail 回调方法，回传参数给 js 端
*/
- (BOOL)init:(NSDictionary *)config success:(UniModuleKeepAliveCallback)success fail:(UniModuleKeepAliveCallback)fail{
    @try {
        //服务器参数
        NSMutableArray *storeArrayM = [NSMutableArray array];
        if (![MopUtils isNULL: config key:@"finStoreConfigs"]) {
            NSMutableArray *configList = config[@"finStoreConfigs"];
            
            NSInteger count = configList.count;
            for (NSInteger i = 0; i < count; i++) {
                NSDictionary *currentConfig = configList[i];
                
                FATStoreConfig *storeConfig = [[FATStoreConfig alloc] init];
                storeConfig.sdkKey = currentConfig[@"sdkKey"];
                storeConfig.sdkSecret = currentConfig[@"sdkSecret"];
                storeConfig.apiServer = currentConfig[@"apiServer"];
                storeConfig.apmServer = [MopUtils isNULL:currentConfig key:@"apmServer"] ? currentConfig[@"apiServer"] : currentConfig[@"apmServer"];
                if ([@"SM" isEqualToString:currentConfig[@"cryptType"]])
                    storeConfig.cryptType = FATApiCryptTypeSM;
                else
                    storeConfig.cryptType = FATApiCryptTypeMD5;
                if (![MopUtils isNULL: currentConfig key:@"encryptServerData"])
                    storeConfig.encryptServerData = [currentConfig[@"encryptServerData"] boolValue];
                if (![MopUtils isNULL:currentConfig key:@"fingerprint"])
                    storeConfig.fingerprint = currentConfig[@"fingerprint"];
                if (![MopUtils isNULL:currentConfig key:@"enablePreloadFramework"])
                    storeConfig.enablePreloadFramework = [currentConfig[@"enablePreloadFramework"] boolValue];
                
                [storeArrayM addObject:storeConfig];
            }
        }
        
        //初始化配置
        FATConfig *fatConfig = [FATConfig configWithStoreConfigs:storeArrayM];
        if (![MopUtils isNULL:config key:@"userId"])
            fatConfig.currentUserId =  config[@"userId"];
        if (![MopUtils isNULL:config key:@"productIdentification"])
            fatConfig.productIdentification = config[@"productIdentification"];
        if (![MopUtils isNULL:config key:@"disableRequestPermissions"])
            fatConfig.disableAuthorize = [config[@"disableRequestPermissions"] boolValue];
        if (![MopUtils isNULL:config key:@"appletAutoAuthorize"])
            fatConfig.appletAutoAuthorize = [config[@"appletAutoAuthorize"] boolValue];
        if (![MopUtils isNULL:config key:@"disableGetSuperviseInfo"])
            fatConfig.disableGetSuperviseInfo = [config[@"disableGetSuperviseInfo"] boolValue];
        if (![MopUtils isNULL:config key:@"ignoreWebviewCertAuth"])
            fatConfig.ignoreWebviewCertAuth = [config[@"ignoreWebviewCertAuth"] boolValue];
        if (![MopUtils isNULL:config key:@"appletIntervalUpdateLimit"])
            fatConfig.appletIntervalUpdateLimit = [config[@"appletIntervalUpdateLimit"] intValue];
        if (![MopUtils isNULL:config key:@"apmExtendInfo"]){
            NSMutableDictionary *apmExtension = [[NSMutableDictionary alloc] init];
            NSMutableArray *apmExtensionList = config[@"apmExtendInfo"];
            NSInteger count = apmExtensionList.count;
            for (NSInteger i = 0; i < count; i++) {
                NSDictionary *currentApm = apmExtensionList[i];
                apmExtension[currentApm[@"key"]] = currentApm[@"value"];
            }
            fatConfig.apmExtension = apmExtension;
        }
        if (![MopUtils isNULL:config key:@"startCrashProtection"])
            fatConfig.startCrashProtection = [config[@"startCrashProtection"] boolValue];
        if (![MopUtils isNULL:config key:@"enableApmDataCompression"])
            fatConfig.enableApmDataCompression = [config[@"enableApmDataCompression"] boolValue];
        if (![MopUtils isNULL:config key:@"appletDebugMode"])
            fatConfig.appletDebugMode = config[@"appletDebugMode"] ? FATAppletDebugModeEnable :
            FATAppletDebugModeForbidden;
        if (![MopUtils isNULL:config key:@"pageCountLimit"])
            fatConfig.pageCountLimit = [config[@"pageCountLimit"] intValue];
        if (![MopUtils isNULL:config key:@"header"]){
            NSMutableDictionary *headerDic = [[NSMutableDictionary alloc] init];
            NSMutableArray *headerList = config[@"header"];
            NSInteger count = headerList.count;
            for (NSInteger i = 0; i < count; i++) {
                NSDictionary *currentHeader = headerList[i];
                headerDic[currentHeader[@"key"]] = currentHeader[@"value"];
            }
            fatConfig.header = headerDic;
        }
        if (![MopUtils isNULL:config key:@"headerPriority"]){
            if ([@"SPECIFIED" isEqualToString:config[@"headerPriority"]])
                fatConfig.headerPriority = FATConfigSpecifiedPriority;
            if ([@"APPLET_FILE" isEqualToString:config[@"headerPriority"]])
                fatConfig.headerPriority = FATConfigAppletFilePriority;
        }
        if (![MopUtils isNULL:config key:@"schemes"])
            fatConfig.schemes = config[@"schemes"];
        if (![MopUtils isNULL:config key:@"locale"])
            fatConfig.language = [@"en" isEqualToString:config[@"locale"]] ? FATPreferredLanguageEnglish : FATPreferredLanguageSimplifiedChinese;
        
        //UI配置
        FATUIConfig *uiConfig = [[FATUIConfig alloc] init];
        if (![MopUtils isNULL:config key:@"appletText"])
            uiConfig.appletText = config[@"appletText"];
        if (![MopUtils isNULL:config key:@"customWebViewUserAgent"])
            uiConfig.appendingCustomUserAgent = config[@"customWebViewUserAgent"];
        if (![MopUtils isNULL:config key:@"uiConfig"]) {
            NSDictionary *uiConfigDic = config[@"uiConfig"];
            if (![MopUtils isNULL:uiConfigDic key:@"navigationBarHeight"])
                uiConfig.navigationBarHeight = [uiConfigDic[@"navigationBarHeight"] floatValue];
            if (![MopUtils isNULL:uiConfigDic key:@"navigationBarTitleLightColor"])
                uiConfig.navigationBarTitleLightColor = [MopUtils colorWithARGB:uiConfigDic[@"navigationBarTitleLightColor"]];
            if (![MopUtils isNULL:uiConfigDic key:@"navigationBarTitleDarkColor"])
                uiConfig.navigationBarTitleDarkColor = [MopUtils colorWithARGB:uiConfigDic[@"navigationBarTitleDarkColor"]];
            if (![MopUtils isNULL:uiConfigDic key:@"navigationBarBackBtnLightColor"])
                uiConfig.navigationBarBackBtnLightColor = [MopUtils colorWithARGB:uiConfigDic[@"navigationBarBackBtnLightColor"]];
            if (![MopUtils isNULL:uiConfigDic key:@"navigationBarBackBtnDarkColor"])
                uiConfig.navigationBarBackBtnDarkColor = [MopUtils colorWithARGB:uiConfigDic[@"navigationBarBackBtnDarkColor"]];
            if (![MopUtils isNULL:uiConfigDic key:@"webViewProgressBarColor"])
                uiConfig.progressBarColor = [MopUtils colorWithARGB:uiConfigDic[@"webViewProgressBarColor"]];
            if (![MopUtils isNULL:uiConfigDic key:@"hideWebViewProgressBar"])
                uiConfig.hideWebViewProgressBar = [uiConfigDic[@"hideWebViewProgressBar"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"moreMenuStyle"])
                uiConfig.moreMenuStyle = [uiConfigDic[@"moreMenuStyle"] intValue] == 0 ? FATMoreViewStyleDefault : FATMoreViewStyleNormal;
            if (![MopUtils isNULL:uiConfigDic key:@"isHideBackHome"])
                uiConfig.hideBackToHome = [uiConfigDic[@"isHideBackHome"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"isHideShareAppletMenu"])
                uiConfig.hideShareAppletMenu = [uiConfigDic[@"isHideShareAppletMenu"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"isHideForwardMenu"])
                uiConfig.hideForwardMenu = [uiConfigDic[@"isHideForwardMenu"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"isHideRefreshMenu"])
                uiConfig.hideRefreshMenu = [uiConfigDic[@"isHideRefreshMenu"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"isHideSettingMenu"])
                uiConfig.hideSettingMenu = [uiConfigDic[@"isHideSettingMenu"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"hideDebugMenu"])
                uiConfig.hideDebugMenu = [uiConfigDic[@"hideDebugMenu"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"isHideFavoriteMenu"])
                uiConfig.hideFavoriteMenu = [uiConfigDic[@"isHideFavoriteMenu"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"isHideAddToDesktopMenu"])
                uiConfig.hideAddToDesktopMenu = [uiConfigDic[@"isHideAddToDesktopMenu"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"isHideFeedbackAndComplaints"])
                uiConfig.hideFeedbackMenu = [uiConfigDic[@"isHideFeedbackAndComplaints"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"autoAdaptDarkMode"])
                uiConfig.autoAdaptDarkMode = [uiConfigDic[@"autoAdaptDarkMode"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"hideTransitionCloseButton"])
                uiConfig.hideTransitionCloseButton = [uiConfigDic[@"hideTransitionCloseButton"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"disableSlideCloseAppletGesture"])
                uiConfig.disableSlideCloseAppletGesture = [uiConfigDic[@"disableSlideCloseAppletGesture"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"disableSlideCloseAppletGesture"])
                uiConfig.disableSlideCloseAppletGesture = [uiConfigDic[@"disableSlideCloseAppletGesture"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"useNativeLiveComponent"])
                uiConfig.useNativeLiveComponent = [uiConfigDic[@"useNativeLiveComponent"] boolValue];
            if (![MopUtils isNULL:uiConfigDic key:@"hideTechSupport"])
                if([uiConfigDic[@"hideTechSupport"] boolValue])
                    fatConfig.baseLoadingViewClass = @"MopLoadingView";
            //分享按钮文字配置
            if (![MopUtils isNULL:uiConfigDic key:@"forwadMenuTitle"]) {
                FATShareItemConfig *shareItemConfig = [[FATShareItemConfig alloc] init];
                shareItemConfig.shareItemString = uiConfigDic[@"forwadMenuTitle"];
                uiConfig.shareItemConfig = shareItemConfig;
            }
            
            //返回按钮配置
            if (![MopUtils isNULL:uiConfigDic key:@"navHomeConfig"]) {
                NSDictionary *navHomeConfigDic = uiConfigDic[@"navHomeConfig"];
                
                FATNavHomeConfig *navHomeConfig = [[FATNavHomeConfig alloc] init];
                if (![MopUtils isNULL:navHomeConfigDic key:@"width"])
                    navHomeConfig.width = [navHomeConfigDic[@"width"] floatValue];
                if (![MopUtils isNULL:navHomeConfigDic key:@"height"])
                    navHomeConfig.height = [navHomeConfigDic[@"height"] floatValue];
                if (![MopUtils isNULL:navHomeConfigDic key:@"cornerRadius"])
                    navHomeConfig.cornerRadius = [navHomeConfigDic[@"cornerRadius"] floatValue];
                if (![MopUtils isNULL:navHomeConfigDic key:@"borderWidth"])
                    navHomeConfig.borderWidth = [navHomeConfigDic[@"borderWidth"] floatValue];
                if (![MopUtils isNULL:navHomeConfigDic key:@"borderLightColor"])
                    navHomeConfig.borderLightColor = [MopUtils colorWithARGB:navHomeConfigDic[@"borderLightColor"]];
                if (![MopUtils isNULL:navHomeConfigDic key:@"borderDarkColor"])
                    navHomeConfig.borderDarkColor = [MopUtils colorWithARGB:navHomeConfigDic[@"borderDarkColor"]];
                if (![MopUtils isNULL:navHomeConfigDic key:@"bgLightColor"])
                    navHomeConfig.bgLightColor = [MopUtils colorWithARGB:navHomeConfigDic[@"bgLightColor"]];
                if (![MopUtils isNULL:navHomeConfigDic key:@"bgDarkColor"])
                    navHomeConfig.bgDarkColor = [MopUtils colorWithARGB:navHomeConfigDic[@"bgDarkColor"]];
                uiConfig.navHomeConfig = navHomeConfig;
            }
            //胶囊按钮配置
            if (![MopUtils isNULL:uiConfigDic key:@"capsuleConfig"]) {
                NSDictionary *capsuleConfigDic = uiConfigDic[@"capsuleConfig"];
                
                FATCapsuleConfig *capsuleConfig = [[FATCapsuleConfig alloc] init];
                if (![MopUtils isNULL:uiConfigDic key:@"hideCapsuleCloseButton"])
                    capsuleConfig.hideCapsuleCloseButton = [uiConfigDic[@"hideCapsuleCloseButton"] boolValue];
                if (![MopUtils isNULL:capsuleConfigDic key:@"capsuleWidth"])
                    capsuleConfig.capsuleWidth = [capsuleConfigDic[@"capsuleWidth"] floatValue];
                if (![MopUtils isNULL:capsuleConfigDic key:@"capsuleHeight"])
                    capsuleConfig.capsuleHeight = [capsuleConfigDic[@"capsuleHeight"] floatValue];
                if (![MopUtils isNULL:capsuleConfigDic key:@"capsuleRightMargin"])
                    capsuleConfig.capsuleRightMargin = [capsuleConfigDic[@"capsuleRightMargin"] floatValue];
                if (![MopUtils isNULL:capsuleConfigDic key:@"capsuleCornerRadius"])
                    capsuleConfig.capsuleCornerRadius = [capsuleConfigDic[@"capsuleCornerRadius"] floatValue];
                if (![MopUtils isNULL:capsuleConfigDic key:@"capsuleBorderWidth"])
                    capsuleConfig.capsuleBorderWidth = [capsuleConfigDic[@"capsuleBorderWidth"] floatValue];
                if (![MopUtils isNULL:capsuleConfigDic key:@"moreBtnWidth"])
                    capsuleConfig.moreBtnWidth = [capsuleConfigDic[@"moreBtnWidth"] floatValue];
                if (![MopUtils isNULL:capsuleConfigDic key:@"moreBtnLeftMargin"])
                    capsuleConfig.moreBtnLeftMargin = [capsuleConfigDic[@"moreBtnLeftMargin"] floatValue];
                if (![MopUtils isNULL:capsuleConfigDic key:@"closeBtnWidth"])
                    capsuleConfig.closeBtnWidth = [capsuleConfigDic[@"closeBtnWidth"] floatValue];
                if (![MopUtils isNULL:capsuleConfigDic key:@"closeBtnLeftMargin"])
                    capsuleConfig.closeBtnLeftMargin = [capsuleConfigDic[@"closeBtnLeftMargin"] floatValue];
                if (![MopUtils isNULL:capsuleConfigDic key:@"capsuleBgLightColor"])
                    capsuleConfig.capsuleBgLightColor = [MopUtils colorWithARGB:capsuleConfigDic[@"capsuleBgLightColor"]];
                if (![MopUtils isNULL:capsuleConfigDic key:@"capsuleBgDarkColor"])
                    capsuleConfig.capsuleBgDarkColor = [MopUtils colorWithARGB:capsuleConfigDic[@"capsuleBgDarkColor"]];
                if (![MopUtils isNULL:capsuleConfigDic key:@"capsuleBorderLightColor"])
                    capsuleConfig.capsuleBorderLightColor = [MopUtils colorWithARGB:capsuleConfigDic[@"capsuleBorderLightColor"]];
                if (![MopUtils isNULL:capsuleConfigDic key:@"capsuleBorderDarkColor"])
                    capsuleConfig.capsuleBorderDarkColor = [MopUtils colorWithARGB:capsuleConfigDic[@"capsuleBorderDarkColor"]];
                uiConfig.capsuleConfig = capsuleConfig;
            } else if (![MopUtils isNULL:uiConfigDic key:@"hideCapsuleCloseButton"]) {
                FATCapsuleConfig *capsuleConfig = [[FATCapsuleConfig alloc] init];
                capsuleConfig.hideCapsuleCloseButton = [uiConfigDic[@"hideCapsuleCloseButton"] boolValue];
                uiConfig.capsuleConfig = capsuleConfig;
            }
            
            //权限弹框配置
            if (![MopUtils isNULL:uiConfigDic key:@"authViewConfig"]) {
                NSDictionary *authViewConfigDic = uiConfigDic[@"authViewConfig"];
                
                FATAuthViewConfig *authViewConfig = [[FATAuthViewConfig alloc] init];
                if (![MopUtils isNULL:authViewConfigDic key:@"appletNameTextSize"]){
                    authViewConfig.appletNameFont = [UIFont systemFontOfSize:[authViewConfigDic[@"appletNameTextSize"] floatValue]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"appletNameLightColor"]){
                    authViewConfig.appletNameLightColor = [MopUtils colorWithARGB:authViewConfigDic[@"appletNameLightColor"]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"appletNameDarkColor"]){
                    authViewConfig.appletNameDarkColor = [MopUtils colorWithARGB:authViewConfigDic[@"appletNameDarkColor"]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"authorizeTitleTextSize"]){
                    authViewConfig.authorizeTitleFont = [UIFont systemFontOfSize:[authViewConfigDic[@"authorizeTitleTextSize"] floatValue]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"authorizeTitleLightColor"]){
                    authViewConfig.authorizeTitleLightColor = [MopUtils colorWithARGB:authViewConfigDic[@"authorizeTitleLightColor"]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"authorizeTitleDarkColor"]){
                    authViewConfig.authorizeTitleDarkColor = [MopUtils colorWithARGB:authViewConfigDic[@"authorizeTitleDarkColor"]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"authorizeDescriptionTextSize"]){
                    authViewConfig.authorizeDescriptionFont = [UIFont systemFontOfSize:[authViewConfigDic[@"authorizeDescriptionTextSize"] floatValue]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"authorizeDescriptionLightColor"]){
                    authViewConfig.authorizeDescriptionLightColor = [MopUtils colorWithARGB:authViewConfigDic[@"authorizeDescriptionLightColor"]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"authorizeDescriptionDarkColor"]){
                    authViewConfig.authorizeDescriptionDarkColor = [MopUtils colorWithARGB:authViewConfigDic[@"authorizeDescriptionDarkColor"]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"agreementTitleTextSize"]){
                    authViewConfig.agreementTitleFont = [UIFont systemFontOfSize:[authViewConfigDic[@"agreementTitleTextSize"] floatValue]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"agreementTitleLightColor"]){
                    authViewConfig.agreementTitleLightColor = [MopUtils colorWithARGB:authViewConfigDic[@"agreementTitleLightColor"]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"agreementTitleDarkColor"]){
                    authViewConfig.agreementTitleDarkColor = [MopUtils colorWithARGB:authViewConfigDic[@"agreementTitleDarkColor"]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"agreementDescriptionTextSize"]){
                    authViewConfig.agreementDescriptionFont = [UIFont systemFontOfSize:[authViewConfigDic[@"agreementDescriptionTextSize"] floatValue]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"agreementDescriptionLightColor"]){
                    authViewConfig.agreementDescriptionLightColor = [MopUtils colorWithARGB:authViewConfigDic[@"agreementDescriptionLightColor"]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"agreementDescriptionDarkColor"]){
                    authViewConfig.agreementDescriptionDarkColor = [MopUtils colorWithARGB:authViewConfigDic[@"agreementDescriptionDarkColor"]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"linkLightColor"]){
                    authViewConfig.linkLightColor = [MopUtils colorWithARGB:authViewConfigDic[@"linkLightColor"]];
                }
                if (![MopUtils isNULL:authViewConfigDic key:@"linkDarkColor"]){
                    authViewConfig.linkDarkColor = [MopUtils colorWithARGB:authViewConfigDic[@"linkDarkColor"]];
                }
                //同意按钮浅色配置
                if (![MopUtils isNULL:authViewConfigDic key:@"allowButtonLightConfig"]){
                    NSDictionary *allowButtonLightConfigDic = authViewConfigDic[@"allowButtonLightConfig"];
                    FATAuthButtonConfig *buttonConfig = [[FATAuthButtonConfig alloc] init];
                    if (![MopUtils isNULL:allowButtonLightConfigDic key:@"cornerRadius"]){
                        buttonConfig.cornerRadius = [allowButtonLightConfigDic[@"cornerRadius"] floatValue];
                    }
                    if (![MopUtils isNULL:allowButtonLightConfigDic key:@"normalBackgroundColor"]){
                        buttonConfig.normalBackgroundColor = [MopUtils colorWithARGB:allowButtonLightConfigDic[@"normalBackgroundColor"]];
                    }
                    if (![MopUtils isNULL:allowButtonLightConfigDic key:@"pressedBackgroundColor"]){
                        buttonConfig.pressedBackgroundColor = [MopUtils colorWithARGB:allowButtonLightConfigDic[@"pressedBackgroundColor"]];
                    }
                    if (![MopUtils isNULL:allowButtonLightConfigDic key:@"normalBorderColor"]){
                        buttonConfig.normalBorderColor = [MopUtils colorWithARGB:allowButtonLightConfigDic[@"normalBorderColor"]];
                    }
                    if (![MopUtils isNULL:allowButtonLightConfigDic key:@"pressedBorderColor"]){
                        buttonConfig.pressedBorderColor = [MopUtils colorWithARGB:allowButtonLightConfigDic[@"pressedBorderColor"]];
                    }
                    if (![MopUtils isNULL:allowButtonLightConfigDic key:@"normalTextColor"]){
                        buttonConfig.normalTextColor = [MopUtils colorWithARGB:allowButtonLightConfigDic[@"normalTextColor"]];
                    }
                    if (![MopUtils isNULL:allowButtonLightConfigDic key:@"pressedTextColor"]){
                        buttonConfig.pressedTextColor = [MopUtils colorWithARGB:allowButtonLightConfigDic[@"pressedTextColor"]];
                    }
                    authViewConfig.allowButtonLightConfig = buttonConfig;
                }
                //同意按钮深色配置
                if (![MopUtils isNULL:authViewConfigDic key:@"allowButtonDarkConfig"]){
                    NSDictionary *allowButtonDarkConfigDic = authViewConfigDic[@"allowButtonDarkConfig"];
                    FATAuthButtonConfig *buttonConfig = [[FATAuthButtonConfig alloc] init];
                    if (![MopUtils isNULL:allowButtonDarkConfigDic key:@"cornerRadius"]){
                        buttonConfig.cornerRadius = [allowButtonDarkConfigDic[@"cornerRadius"] floatValue];
                    }
                    if (![MopUtils isNULL:allowButtonDarkConfigDic key:@"normalBackgroundColor"]){
                        buttonConfig.normalBackgroundColor = [MopUtils colorWithARGB:allowButtonDarkConfigDic[@"normalBackgroundColor"]];
                    }
                    if (![MopUtils isNULL:allowButtonDarkConfigDic key:@"pressedBackgroundColor"]){
                        buttonConfig.pressedBackgroundColor = [MopUtils colorWithARGB:allowButtonDarkConfigDic[@"pressedBackgroundColor"]];
                    }
                    if (![MopUtils isNULL:allowButtonDarkConfigDic key:@"normalBorderColor"]){
                        buttonConfig.normalBorderColor = [MopUtils colorWithARGB:allowButtonDarkConfigDic[@"normalBorderColor"]];
                    }
                    if (![MopUtils isNULL:allowButtonDarkConfigDic key:@"pressedBorderColor"]){
                        buttonConfig.pressedBorderColor = [MopUtils colorWithARGB:allowButtonDarkConfigDic[@"pressedBorderColor"]];
                    }
                    if (![MopUtils isNULL:allowButtonDarkConfigDic key:@"normalTextColor"]){
                        buttonConfig.normalTextColor = [MopUtils colorWithARGB:allowButtonDarkConfigDic[@"normalTextColor"]];
                    }
                    if (![MopUtils isNULL:allowButtonDarkConfigDic key:@"pressedTextColor"]){
                        buttonConfig.pressedTextColor = [MopUtils colorWithARGB:allowButtonDarkConfigDic[@"pressedTextColor"]];
                    }
                    authViewConfig.allowButtonDarkConfig = buttonConfig;
                }
                //拒绝按钮浅色配置
                if (![MopUtils isNULL:authViewConfigDic key:@"rejectButtonLightConfig"]){
                    NSDictionary *rejectButtonLightConfigDic = authViewConfigDic[@"rejectButtonLightConfig"];
                    FATAuthButtonConfig *buttonConfig = [[FATAuthButtonConfig alloc] init];
                    if (![MopUtils isNULL:rejectButtonLightConfigDic key:@"cornerRadius"]){
                        buttonConfig.cornerRadius = [rejectButtonLightConfigDic[@"cornerRadius"] floatValue];
                    }
                    if (![MopUtils isNULL:rejectButtonLightConfigDic key:@"normalBackgroundColor"]){
                        buttonConfig.normalBackgroundColor = [MopUtils colorWithARGB:rejectButtonLightConfigDic[@"normalBackgroundColor"]];
                    }
                    if (![MopUtils isNULL:rejectButtonLightConfigDic key:@"pressedBackgroundColor"]){
                        buttonConfig.pressedBackgroundColor = [MopUtils colorWithARGB:rejectButtonLightConfigDic[@"pressedBackgroundColor"]];
                    }
                    if (![MopUtils isNULL:rejectButtonLightConfigDic key:@"normalBorderColor"]){
                        buttonConfig.normalBorderColor = [MopUtils colorWithARGB:rejectButtonLightConfigDic[@"normalBorderColor"]];
                    }
                    if (![MopUtils isNULL:rejectButtonLightConfigDic key:@"pressedBorderColor"]){
                        buttonConfig.pressedBorderColor = [MopUtils colorWithARGB:rejectButtonLightConfigDic[@"pressedBorderColor"]];
                    }
                    if (![MopUtils isNULL:rejectButtonLightConfigDic key:@"normalTextColor"]){
                        buttonConfig.normalTextColor = [MopUtils colorWithARGB:rejectButtonLightConfigDic[@"normalTextColor"]];
                    }
                    if (![MopUtils isNULL:rejectButtonLightConfigDic key:@"pressedTextColor"]){
                        buttonConfig.pressedTextColor = [MopUtils colorWithARGB:rejectButtonLightConfigDic[@"pressedTextColor"]];
                    }
                    authViewConfig.rejectButtonLightConfig = buttonConfig;
                }
                //拒绝按钮深色配置
                if (![MopUtils isNULL:authViewConfigDic key:@"rejectButtonDarkConfig"]){
                    NSDictionary *rejectButtonDarkConfigDic = authViewConfigDic[@"rejectButtonDarkConfig"];
                    FATAuthButtonConfig *buttonConfig = [[FATAuthButtonConfig alloc] init];
                    if (![MopUtils isNULL:rejectButtonDarkConfigDic key:@"cornerRadius"]){
                        buttonConfig.cornerRadius = [rejectButtonDarkConfigDic[@"cornerRadius"] floatValue];
                    }
                    if (![MopUtils isNULL:rejectButtonDarkConfigDic key:@"normalBackgroundColor"]){
                        buttonConfig.normalBackgroundColor = [MopUtils colorWithARGB:rejectButtonDarkConfigDic[@"normalBackgroundColor"]];
                    }
                    if (![MopUtils isNULL:rejectButtonDarkConfigDic key:@"pressedBackgroundColor"]){
                        buttonConfig.pressedBackgroundColor = [MopUtils colorWithARGB:rejectButtonDarkConfigDic[@"pressedBackgroundColor"]];
                    }
                    if (![MopUtils isNULL:rejectButtonDarkConfigDic key:@"normalBorderColor"]){
                        buttonConfig.normalBorderColor = [MopUtils colorWithARGB:rejectButtonDarkConfigDic[@"normalBorderColor"]];
                    }
                    if (![MopUtils isNULL:rejectButtonDarkConfigDic key:@"pressedBorderColor"]){
                        buttonConfig.pressedBorderColor = [MopUtils colorWithARGB:rejectButtonDarkConfigDic[@"pressedBorderColor"]];
                    }
                    if (![MopUtils isNULL:rejectButtonDarkConfigDic key:@"normalTextColor"]){
                        buttonConfig.normalTextColor = [MopUtils colorWithARGB:rejectButtonDarkConfigDic[@"normalTextColor"]];
                    }
                    if (![MopUtils isNULL:rejectButtonDarkConfigDic key:@"pressedTextColor"]){
                        buttonConfig.pressedTextColor = [MopUtils colorWithARGB:rejectButtonDarkConfigDic[@"pressedTextColor"]];
                    }
                    authViewConfig.rejectButtonDarkConfig = buttonConfig;
                }
                uiConfig.authViewConfig = authViewConfig;
            }
        }
        
        BOOL SUCCESS = [[FATClient sharedClient] initWithConfig:fatConfig uiConfig:uiConfig error:nil];
        
        if(SUCCESS) success(@{@"code":@"success"},YES);
        else fail(@{@"code":@"fail",@"msg": @"初始化失败"},YES);
        return YES;
    }@catch(NSException *exceptioon) {
        fail(@{@"code":@"fail",@"msg": @"初始化参数异常"},YES);
        
    }@finally{
        
    }
    return NO;
}

@end
