//
//  MopCallbackUtils.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/19.
//  Copyright © 2023 DCloud. All rights reserved.
//

#ifndef MopCallbackUtils_h
#define MopCallbackUtils_h
#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

@interface MopCallbackUtils : NSObject

+ (NSString *) addCallback:(FATExtensionApiCallback) iCallback;

+ (FATExtensionApiCallback) getCallback:(NSString *) uuid;

+ (void) removeCallback:(NSString *) uuid;

@end

#endif /* MopCallbackUtils_h */
