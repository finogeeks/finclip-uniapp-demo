//
//  MopCallbackUtils.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/19.
//  Copyright © 2023 DCloud. All rights reserved.
//
#import "MopCallbackUtils.h"

@implementation MopCallbackUtils

 static NSMutableDictionary<NSString*,FATExtensionApiCallback> * callbackMap;

+ (NSString *) addCallback:(FATExtensionApiCallback) iCallback {
    if (!callbackMap)
         callbackMap = [[NSMutableDictionary<NSString*,FATExtensionApiCallback> alloc] init];
    
    CFUUIDRef uuid_ref = CFUUIDCreate(NULL);
    CFStringRef uuid_string_ref= CFUUIDCreateString(NULL, uuid_ref);
    NSString *uuid = [[NSString stringWithString:(__bridge NSString *)uuid_string_ref] lowercaseString];
    CFRelease(uuid_ref);
    CFRelease(uuid_string_ref);
    
    callbackMap[uuid] = iCallback;
    
    return uuid;
}

+ (FATExtensionApiCallback) getCallback:(NSString *) uuid {
    return  callbackMap[uuid];
}

+ (void) removeCallback:(NSString *) uuid {
    [callbackMap removeObjectForKey:uuid];
}

@end

