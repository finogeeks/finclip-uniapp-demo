//
//  MopExtension.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//

#ifndef MopExtension_h
#define MopExtension_h

#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

#import "DCUniModule.h"
#import "MopCallbackUtils.h"

@interface MopExtension : NSObject
 
+ (instancetype)shareInstance;

- (void)registerExtensionApi:(NSString *) name callback:(UniModuleKeepAliveCallback)callback;

- (void)unRegisterExtensionApi:(NSString *) name;

- (void)registerWebExtensionApi:(NSString *) name callback:(UniModuleKeepAliveCallback)callback;

- (void)unRegisterWebExtensionApi:(NSString *) name;

- (void)onSuccess:(NSString *) uuid options:(NSDictionary *)options;

- (void)onFail:(NSString *) uuid options:(NSDictionary *)options;

@end

#endif /* MopExtension_h */
