//
//  FINButtonDelegate.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2022/11/4.
//  Copyright © 2022 DCloud. All rights reserved.
//
#import "MopButtonOpenTypeDelegate.h"

@implementation MopButtonOpenTypeDelegate

static MopButtonOpenTypeDelegate *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopButtonOpenTypeDelegate alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}


- (void) setChooseAvatar : (NSString *) chooseAvatar {
    self.avatarUrl = chooseAvatar;
}

- (void) setPhoneNumber : (NSString *) phoneNumber {
    self.phone = phoneNumber;
}

- (void) setUserInfo : (NSDictionary *) userInfo {
    self.info = userInfo;
}

- (void) setOpenTypeShareAppMessage: (UniModuleKeepAliveCallback) shareCallback{
    self.shareCallback = shareCallback;
}

- (BOOL)forwardAppletWithInfo:(NSDictionary *)contentInfo completion:(void (^)(FATExtensionCode code, NSDictionary *result)) completion {
    if(self.shareCallback) {
        NSString *uuid = [MopCallbackUtils addCallback:completion];
        self.shareCallback(@{@"uuid": uuid, @"appInfo": contentInfo, @"bitmap": contentInfo[@"appThumbnail"]}, YES);
    }
    return YES;
}
 
-(BOOL)getUserInfoWithAppletInfo:(FATAppletInfo *)appletInfo bindGetUserInfo:(void (^)(NSDictionary *result))bindGetUserInfo{
    if (self.info) {
        bindGetUserInfo(self.info);
        return YES;
    }
    return NO;
}

- (BOOL)getUserProfileWithAppletInfo:(FATAppletInfo *)appletInfo bindGetUserProfile:(void (^)(NSDictionary *result))bindGetUserProfile {
    if (self.info) {
        bindGetUserProfile(self.info);
        return YES;
    }
    return NO;
}

-(BOOL)getPhoneNumberWithAppletInfo:(FATAppletInfo *)appletInfo bindGetPhoneNumber:(void (^)(NSDictionary *result))bindGetPhoneNumber
{
    if (self.phone) {
        NSDictionary *result = [NSDictionary dictionaryWithObject:self.phone forKey:@"phoneNumber"];
        bindGetPhoneNumber(result);
        return YES;
    }
    return NO;
}

-(BOOL)chooseAvatarWithAppletInfo:(FATAppletInfo *)appletInfo bindChooseAvatar:(void (^)(NSDictionary *result))bindChooseAvatar
{
    if (self.avatarUrl) {
        NSDictionary *result = [NSDictionary dictionaryWithObject:self.avatarUrl forKey:@"avatarUrl"];
        bindChooseAvatar(result);
        return YES;
    }
    return NO;
}

@end
