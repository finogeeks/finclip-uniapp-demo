//
//  MopConfigurationDelegate.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/20.
//  Copyright © 2023 DCloud. All rights reserved.
//

#ifndef MopConfigurationDelegate_h
#define MopConfigurationDelegate_h
#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

#import "DCUniModule.h"

@interface MopConfigurationDelegate : NSObject<FATAppletConfigurationDelegate>
 
+ (instancetype)shareInstance;

@property (nonatomic, strong) NSDictionary *grayExtension;

- (void) setGrayAppletVersionConfigs:(NSDictionary *)grayExtension;

@end

#endif /* MopConfigurationDelegate_h */
