//
//  MopbuttonOpenTypeDelegate.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2022/11/4.
//  Copyright © 2022 DCloud. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

#import "DCUniModule.h"
#import "MopCallbackUtils.h"

@interface MopButtonOpenTypeDelegate : NSObject<FATAppletButtonOpenTypeDelegate>
 
+ (instancetype)shareInstance;

@property (nonatomic, strong) NSDictionary *info;
@property (nonatomic, strong) NSString  *avatarUrl;
@property (nonatomic, strong) NSString  *phone;
@property (nonatomic, strong) UniModuleKeepAliveCallback shareCallback;


-(void) setChooseAvatar:(NSString * ) chooseAvatar;
-(void) setPhoneNumber:(NSString * ) phoneNumber;
-(void) setUserInfo:(NSDictionary * ) userInfo;
-(void) setOpenTypeShareAppMessage: (UniModuleKeepAliveCallback) shareCallback;

@end

