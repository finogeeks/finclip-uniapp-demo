//
//  MopLifeCycleDelegate.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2022/11/4.
//  Copyright © 2022 DCloud. All rights reserved.
//
#import "MopLifeCycleDelegate.h"

@implementation MopLifeCycleDelegate

static MopLifeCycleDelegate *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopLifeCycleDelegate alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didOpenCompletion:(NSError *)error{
    if (self.onOpen) {
        self.onOpen(@{@"appId":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didCloseCompletion:(NSError *)error
{
    if (self.onClose) {
        self.onClose(@{@"appId":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo initCompletion:(NSError *)error
{
    if (self.onInitComplete) {
        self.onInitComplete(@{@"appId":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didActive:(NSError *)error
{
    if (self.onInActive) {
        self.onInActive(@{@"appId":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo resignActive:(NSError *)error
{
    if (self.onActive) {
        self.onActive(@{@"appId":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didFail:(NSError *)error
{
    if (self.onOpenFailure) {
        self.onOpenFailure(@{@"appId":appletInfo.appId,@"errorMsg":[NSString stringWithFormat: @"%ld", error.code] },YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo dealloc:(NSError *)error
{
    if (self.onDestroy) {
        self.onDestroy(@{@"appId":appletInfo.appId },YES);
    }
}

@end
