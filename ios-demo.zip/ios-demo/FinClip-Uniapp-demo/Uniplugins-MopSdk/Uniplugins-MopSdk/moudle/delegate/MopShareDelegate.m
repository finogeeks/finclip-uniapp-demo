//
//  MopShareDelegate.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/20.
//  Copyright © 2023 DCloud. All rights reserved.
//

#import "MopShareDelegate.h"

@implementation MopShareDelegate

static MopShareDelegate *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopShareDelegate alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

- (void) setShareAppMessage: (UniModuleKeepAliveCallback) shareCallback{
    self.shareCallback = shareCallback;
}

- (void)applet:(FATAppletInfo *)appletInfo didClickShareItem:(NSDictionary *)shareDict {
    if(self.shareCallback) {
        self.shareCallback(@{@"appInfo": [MopUtils appletToDictionary:appletInfo], @"pagePath": shareDict[@"miniAppPath"]}, YES);
    }
}

@end
