//
//  MopOther.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//
#import "MopOther.h"

@implementation MopOther

static MopOther *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopOther alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

- (void) setUserId:(NSString *) userId {
    [FATClient sharedClient].config.currentUserId = userId;
}

- (void) getFinFileAbsolutePath:(NSString *) appId finFile:(NSString *) finFile onCallback:(UniModuleKeepAliveCallback) onCallback {
    @try {
        NSString *path = [[FATClient sharedClient] fat_absolutePathWithPath:finFile];
        if (onCallback) onCallback(@{@"path": path},YES);
    }@catch(NSException *error){
        if (onCallback) onCallback(nil, YES);
    }@finally {
        
    }
}

@end
