//
//  FATShareComponent.h
//  FinAppletShare
//
//  Created by 王兆耀 on 2023/2/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FATShareComponent : NSObject

+ (NSString *)SDKVersion;

+ (BOOL)registerComponent:(NSString *)appld universalLink:(NSString *)universalLink scheme:(NSString *)scheme __attribute__((deprecated("该api(自2.40.11起)废弃，请使用registerComponent:customUrl:universalLink:scheme:appDownloadLink:")));

/// 分享SDK的初始化方法 since:2.40.11
/// - Parameters:
///   - appld: 小程序id
///   - customUrl: 自定义分享的短链，可不传
///   - universalLink: universalLink
///   - scheme: 打开App的scheme，如果采用fat+${SDKKey的16位小写md5}的方式生成可以打开对应的小程序。否则只能打开App
///   - appDownloadLink: App的下载链接 可不传
+ (BOOL)registerComponent:(NSString *)appld customUrl:(NSString *)customUrl universalLink:(NSString *)universalLink scheme:(NSString *)scheme appDownloadLink:(NSString *)appDownloadLink;

/// 分享SDK的初始化方法 since:2.40.11
/// - Parameters:
///   - appld: 小程序id
///   - customUrl: 自定义分享的短链，可不传
///   - universalLink: universalLink
///   - scheme: 打开App的scheme，如果采用fat+${SDKKey的16位小写md5}的方式生成可以打开对应的小程序。否则只能打开App
///   - appDownloadLink: App的下载链接 可不传
///   - compression: 图片的压缩比例 范围为0～1，默认1
+ (BOOL)registerComponent:(NSString *)appld customUrl:(NSString *)customUrl universalLink:(NSString *)universalLink scheme:(NSString *)scheme appDownloadLink:(NSString *)appDownloadLink compression:(CGFloat)compression;

@end

NS_ASSUME_NONNULL_END
