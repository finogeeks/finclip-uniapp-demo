//
//  FinAppletTXMap.h
//  FinAppletTXMap
//
//  Created by 王兆耀 on 2022/10/17.
//

#import <Foundation/Foundation.h>
#import "FATTXMapComponent.h"

//! Project version number for FinAppletTXMap.
FOUNDATION_EXPORT double FinAppletTXMapVersionNumber;

//! Project version string for FinAppletTXMap.
FOUNDATION_EXPORT const unsigned char FinAppletTXMapVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FinAppletTXMap/PublicHeader.h>

