//
//  FinAppletCalendar.h
//  FinAppletCalendar
//
//  Created by 王兆耀 on 2023/6/7.
//

#import <Foundation/Foundation.h>

//! Project version number for FinAppletCalendar.
FOUNDATION_EXPORT double FinAppletCalendarVersionNumber;

//! Project version string for FinAppletCalendar.
FOUNDATION_EXPORT const unsigned char FinAppletCalendarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FinAppletCalendar/PublicHeader.h>

#import <FinAppletCalendar/FATCalendarComponent.h>

