//
//  FinAppletWXExt.h
//  FinAppletWXExt
//
//  Created by 王兆耀 on 2022/8/17.
//

#import <Foundation/Foundation.h>

//! Project version number for FinAppletWXExt.
FOUNDATION_EXPORT double FinAppletWXExtVersionNumber;

//! Project version string for FinAppletWXExt.
FOUNDATION_EXPORT const unsigned char FinAppletWXExtVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FinAppletWXExt/PublicHeader.h>

#import "FATWXExtComponent.h"
#import "FATWXApiManager.h"
#import "FATDelegateClientHelper.h"
