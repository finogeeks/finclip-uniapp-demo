//
//  FATWebRTCComponent.h
//  FinAppletWebRTC
//
//  Created by 王滔 on 2021/11/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FATWebRTCComponent : NSObject

+ (NSString *)SDKVersion;

+ (void)registerComponent;

@end

NS_ASSUME_NONNULL_END
