# FinClip-Uniapp-demo

#### IOS插件使用介绍
1、下载Uniapp SDK 
百度云点击下载SDK，提取码: rvdy： 
https://pan.baidu.com/s/1ExtRytSAuOpGjl4e4m9Hdw?pwd=rvdy 

和彩云点击下载SDK，提取码: wLYN：
https://caiyun.139.com/m/i?115CoA5Cy156K

2、将下载的SDK进行解压得Libs，将下面的文件全部拷贝至当前工程的SDK/Libs目录下
3、使用xcode打开FinClip-Uniapp-demo.xcodeproj
4、直接运行xcode项目
