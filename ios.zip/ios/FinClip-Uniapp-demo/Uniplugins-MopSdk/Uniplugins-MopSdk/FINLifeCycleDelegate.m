//
//  FINLifeCycleDelegate.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2022/11/4.
//  Copyright © 2022 DCloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FINLifeCycleDelegate.h"
#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

@implementation FINLifeCycleDelegate

static FINLifeCycleDelegate *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[FINLifeCycleDelegate alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didOpenCompletion:(NSError *)error{
    if (self.onCloseButtonClicked) {
        self.onCloseButtonClicked(appletInfo.appId,YES);
    }
    if (self.onStart) {
        self.onStart(@{@"appid":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didCloseCompletion:(NSError *)error
{
    if (self.onCloseButtonClicked) {
        self.onCloseButtonClicked(appletInfo.appId,YES);
    }
    if (self.onStop) {
        self.onStop(@{@"appid":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo initCompletion:(NSError *)error
{
    if (self.onInitComplete) {
        self.onInitComplete(@{@"appid":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didActive:(NSError *)error
{
    if (self.onResume) {
        self.onResume(@{@"appid":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo resignActive:(NSError *)error
{
    if (self.onPause) {
        self.onPause(@{@"appid":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didFail:(NSError *)error
{
    if (self.onFailure) {
        self.onFailure(@{@"appid":appletInfo.appId,@"code":[NSString stringWithFormat: @"%ld", error.code] },YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo dealloc:(NSError *)error
{
    if (self.onDestroy) {
        self.onDestroy(@{@"appid":appletInfo.appId },YES);
    }
}

@end
