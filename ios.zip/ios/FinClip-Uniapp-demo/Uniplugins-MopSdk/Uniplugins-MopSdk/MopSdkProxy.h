#import <Foundation/Foundation.h>
#import "UniPluginProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface MopSdkProxy : NSObject <UniPluginProtocol>

@end

NS_ASSUME_NONNULL_END
