//
//  MopApplet.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//
#import "MopApplet.h"

@implementation MopApplet

static MopApplet *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopApplet alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

-(void)setAppletLifecycleCallback:(UniModuleKeepAliveCallback)onInitComplete onOpen:(UniModuleKeepAliveCallback)onOpen
                    onOpenFailure:(UniModuleKeepAliveCallback)onOpenFailure
                       onInActive:(UniModuleKeepAliveCallback)onInActive
                         onActive:(UniModuleKeepAliveCallback)onActive
                          onClose:(UniModuleKeepAliveCallback)onClose
                        onDestroy:(UniModuleKeepAliveCallback)onDestroy {
    [MopLifeCycleDelegate shareInstance].onInitComplete = onInitComplete;
    [MopLifeCycleDelegate shareInstance].onOpen = onOpen;
    [MopLifeCycleDelegate shareInstance].onOpenFailure = onOpenFailure;
    [MopLifeCycleDelegate shareInstance].onInActive = onInActive;
    [MopLifeCycleDelegate shareInstance].onActive = onActive;
    [MopLifeCycleDelegate shareInstance].onClose = onClose;
    [MopLifeCycleDelegate shareInstance].onDestroy = onDestroy;
    [FATClient sharedClient].lifeCycleDelegate = [MopLifeCycleDelegate shareInstance];
}

- (void)openApplet:(NSDictionary *)options onSuccess:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback)onProgress {
    @try {
        FATAppletRequest *request = [[FATAppletRequest alloc] init];
        request.appletId =  options[@"appId"];
        request.apiServer = options[@"apiServer"];
        if (![MopUtils isNULL:options key:@"appTitle"])
            request.appName = options[@"appTitle"];
        if (![MopUtils isNULL:options key:@"appAvatar"])
            request.appletLogo = options[@"appAvatar"];
        if (![MopUtils isNULL:options key:@"sequence"])
            request.sequence = [options[@"sequence"] numberValue];
        if (![MopUtils isNULL:options key:@"startParams"]) {
            request.startParams = options[@"startParams"];
        }
        if (![MopUtils isNULL:options key:@"schemes"]) {
            request.schemes = options[@"schemes"];
        }
        if (![MopUtils isNULL:options key:@"hideMiniProgramCloseButton"]) {
            request.hideMiniProgramCloseButton = [options[@"hideMiniProgramCloseButton"] boolValue];
        }
        if (![MopUtils isNULL:options key:@"hideMiniProgramMoreButton"]) {
            request.hideMiniProgramMoreButton = [options[@"hideMiniProgramMoreButton"] boolValue];
        }
        if (![MopUtils isNULL:options key:@"from"]) {
            request.from = [options[@"from"] numberValue];
        }
        if (![MopUtils isNULL:options key:@"anim"]) {
            NSString *anim = options[@"anim"];
            if ([@"RightToLeft" isEqualToString:anim]) {
                request.transitionStyle = FATTranstionStylePush;
            }else {
                request.transitionStyle = FATTranstionStyleUp;
            }
        }
        UIViewController *VC = [MopUtils getCurrentVC];
        [[FATClient sharedClient] startAppletWithRequest:request InParentViewController:VC completion:^(BOOL result, FATError *error) {
            if (error) {
                if(onFail) onFail(@{@"code": [NSString stringWithFormat: @"%ld", error.code], @"message": error.description },YES);
            } else{
                if(onSuccess) onSuccess(@{@"code": @"success", @"message": @"打开成功" },YES);
            }
        } closeCompletion:^{
        }];
    }@catch(NSException *error){
        if(onFail) onFail(@{@"code": @"-1", @"message": error.reason },YES);
    }@finally {
        
    }
}

- (void)openAppletByQrcode:(NSDictionary *)options onSuccess:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback)onProgress{
    @try {
        FATAppletQrCodeRequest *qrcodeRequest = [[FATAppletQrCodeRequest alloc] init];
        qrcodeRequest.qrCode =  options[@"qrCode"];
        if (![MopUtils isNULL:options key:@"from"]) {
            qrcodeRequest.from = [options[@"from"] numberValue];
        }
        if (![MopUtils isNULL:options key:@"anim"]) {
            NSString *anim = options[@"anim"];
            if ([@"RightToLeft" isEqualToString:anim]) {
                qrcodeRequest.transitionStyle = FATTranstionStylePush;
            }else {
                qrcodeRequest.transitionStyle = FATTranstionStyleUp;
            }
        }
        
        UIViewController *VC = [MopUtils getCurrentVC];
        [[FATClient sharedClient] startAppletWithQrCodeRequest:qrcodeRequest inParentViewController:VC requestBlock:^(BOOL result, FATError *error) {
            
        } completion:^(BOOL result, FATError *error) {
            if (error) {
                if(onFail) onFail(@{@"code": [NSString stringWithFormat: @"%ld", error.code], @"message": error.description },YES);
            } else{
                if(onSuccess) onSuccess(@{@"code": @"success", @"message": @"打开成功" },YES);
            }
        } closeCompletion:^{
        }];
    }@catch(NSException *error){
        if(onFail) onFail(@{@"code": @"-1", @"message": error.reason },YES);
    }@finally {
        
    }
}

- (void)searchApplets:(NSDictionary *)options onSuccess:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback)onProgress {
    @try {
        FATSearchAppletRequest* request =  [[FATSearchAppletRequest alloc] init];
        request.apiServer =  options[@"apiServer"];
        request.text = options[@"text"];
        [[FATClient sharedClient] searchAppletsWithRequest:request completion:^(NSDictionary *result, NSError *error) {
            if (error) {
                if(onFail) onFail(@{@"code": [NSString stringWithFormat: @"%ld", error.code], @"message": error.description },YES);
            } else{
                if(onSuccess) onSuccess(result,YES);
            }
        }];
    }@catch(NSException *error){
        if(onFail) onFail(@{@"code": @"-1", @"message": error.reason },YES);
    }@finally {
        
    }
}

- (void) downloadApplets: (NSDictionary *) options onSuccess:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback)  onFail {
    @try {
        BOOL isBatchDownloadApplets = false;
        if([MopUtils isNULL:options key:@"isBatchDownloadApplets"]) {
            isBatchDownloadApplets = [options[@"isBatchDownloadApplets"] boolValue];
        }
        [[FATClient sharedClient] downloadApplets:options[@"appIds"] apiServer:options[@"apiServer"] isBatchDownloadApplets:isBatchDownloadApplets complete:^(NSArray *results, FATError *error) {
            if (error) {
                if(onFail) onFail(@{@"code": [NSString stringWithFormat: @"%ld", error.code], @"message": error.description },YES);
            } else{
                if(onSuccess) onSuccess(results,YES);
            }
        }];
    }@catch(NSException *error){
        if(onFail) onFail(@{@"code": @"-1", @"message": error.reason },YES);
    }@finally {
        
    }
}

- (void) captureAppletPicture: (NSString *) appId
    snapShotWholePage:(BOOL *) snapShotWholePage
    onSuccess:(UniModuleKeepAliveCallback) onSuccess
    onFail:(UniModuleKeepAliveCallback)  onFail{
    @try {
        UIImage
        *appletImage = [[FATClient sharedClient] getCurrentAppletImage];
        NSData *data = UIImagePNGRepresentation(appletImage);
        NSString *encodedImageStr = [data base64EncodedStringWithOptions:0];
        if(onSuccess) onSuccess(@{@"bitmap": encodedImageStr},YES);
    }@catch(NSException *error){
        if(onFail) onFail(@{@"code": @"-1", @"message": error.reason },YES);
    }@finally {
        
    }
}

- (void) moveMiniProgramToFront:(NSString *) appId {
}

- (void) moveAppToFront {
    [[FATClient sharedClient] closeAllAppletsWithCompletion:^{
    }];
}

- (void) currentAppletId:(UniModuleKeepAliveCallback) onCallback {
    @try {
        FATAppletInfo *appletInfo = [[FATClient sharedClient] currentApplet];
        onCallback(@{@"appId":appletInfo ? appletInfo.appId : @""}, YES);
    }@catch(NSException *error){
        onCallback(nil, YES);
    }@finally {
        
    }
}

- (void) currentApplet: (UniModuleKeepAliveCallback) onCallback {
    @try {
        FATAppletInfo *appletInfo = [[FATClient sharedClient] currentApplet];
        if(appletInfo)
            onCallback([MopUtils appletToDictionary:appletInfo],YES);
        else onCallback(nil, YES);
    }@catch(NSException *error){
        onCallback(nil, YES);
    }@finally {
        
    }
}

- (void) getUsedApplet:(NSString *) appId onCallback:(UniModuleKeepAliveCallback) onCallback {
    @try {
        BOOL isTrue = false;
        NSArray *appletInfoList = [[FATClient sharedClient] getAppletsFromLocalCache];
        NSUInteger len = appletInfoList.count;
        for(NSUInteger i=0; i<len; i++){
           FATAppletInfo *appletInfo = appletInfoList[i];
            if ([appletInfo.appId isEqualToString: appId]) {
                onCallback([MopUtils appletToDictionary:appletInfo] , YES);
                isTrue = true;
                break;
            }
        }
        if (!isTrue)  onCallback(nil, YES);
    }@catch(NSException *error){
        onCallback(nil, YES);
    }@finally {
        
    }
}

- (void) getUsedApplets: (UniModuleKeepAliveCallback) onCallback {
    @try {
        NSArray *appletInfoList = [[FATClient sharedClient] getAppletsFromLocalCache];
        NSMutableArray *tempArray = [[NSMutableArray alloc] init];
        NSUInteger len = appletInfoList.count;
        for(NSUInteger i=0; i<len; i++){
           FATAppletInfo *appletInfo = appletInfoList[i];
            [tempArray addObject:[MopUtils appletToDictionary:appletInfo]];
        }
        onCallback(tempArray,YES);
    }@catch(NSException *error){
        onCallback(nil, YES);
    }@finally {
        
    }
}

- (void) isUsedApplet:(NSString *) appId onCallback:(UniModuleKeepAliveCallback) onCallback {
    @try {
        BOOL isTrue = false;
        NSArray *appletInfoList = [[FATClient sharedClient] getAppletsFromLocalCache];
        NSUInteger len = appletInfoList.count;
        for(NSUInteger i=0; i<len; i++){
           FATAppletInfo *appletInfo = appletInfoList[i];
            if ([appletInfo.appId isEqualToString: appId]) {
                onCallback(@{@"isUse":@true},YES);
                isTrue = true;
                break;
            }
        }
        if(!isTrue) onCallback(@{@"isUse":@false}, YES);
    }@catch(NSException *error){
        onCallback(@{@"isUse":@false}, YES);
    }@finally {
        
    }
}

- (void)closeApplet:(NSString *)appId {
    [[FATClient sharedClient] closeApplet:appId animated:YES completion:^{
    }];
}

- (void)closeApplets {
    [[FATClient sharedClient] closeAllAppletsWithCompletion:^{
    }];
}

- (void)finishRunningApplet:(NSString *)appId {
    [[FATClient sharedClient] clearMemeryApplet:appId];
}

- (void)finishRunningApplets {
    [[FATClient sharedClient] clearMemoryCache];
}

- (void)clearApplet:(NSString *) appId {
    [[FATClient sharedClient] removeAppletFromLocalCache:appId];
}

- (void)clearApplets {
    [[FATClient sharedClient] clearLocalApplets];
}

@end
