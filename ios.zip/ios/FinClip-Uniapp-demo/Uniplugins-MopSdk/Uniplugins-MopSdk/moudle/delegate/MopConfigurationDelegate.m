//
//  MopConfigurationDelegate.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/20.
//  Copyright © 2023 DCloud. All rights reserved.
//
#import "MopConfigurationDelegate.h"

@implementation MopConfigurationDelegate

static MopConfigurationDelegate *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopConfigurationDelegate alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}


- (void) setGrayAppletVersionConfigs:(NSDictionary *)grayExtension {
    self.grayExtension = grayExtension;
}

- (NSDictionary *)grayExtensionWithAppletId:(NSString *)appletId
{
    return self.grayExtension;
}

@end
