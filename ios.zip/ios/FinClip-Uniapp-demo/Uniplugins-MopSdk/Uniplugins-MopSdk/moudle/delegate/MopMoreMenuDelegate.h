//
//  MopMoreMenuDelegate.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/20.
//  Copyright © 2023 DCloud. All rights reserved.
//

#ifndef MopMoreMenuDelegate_h
#define MopMoreMenuDelegate_h
#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

#import "DCUniModule.h"
#import "MopCallbackUtils.h"
#import "MopUtils.h"

@interface MopMoreMenuDelegate : NSObject<FATAppletMoreMenuDelegate>
 
+ (instancetype)shareInstance;

@property (nonatomic, strong) NSArray<id<FATAppletMenuProtocol>> *menuItems;

@property (nonatomic, strong) UniModuleKeepAliveCallback onRegisteredMoreMenuItemClicked;


-(void) setRegisteredMoreMenuItems:(NSArray<id<FATAppletMenuProtocol>> *) menuItems onRegisteredMoreMenuItemClicked:(UniModuleKeepAliveCallback) onRegisteredMoreMenuItemClicked;

@end

#endif /* MopMoreMenuDelegate_h */
