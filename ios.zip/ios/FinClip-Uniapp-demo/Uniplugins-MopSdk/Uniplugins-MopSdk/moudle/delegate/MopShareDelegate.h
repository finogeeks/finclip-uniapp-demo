//
//  MopShareItemDelegate.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/20.
//  Copyright © 2023 DCloud. All rights reserved.
//

#ifndef MopShareDelegate_h
#define MopShareDelegate_h
#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

#import "DCUniModule.h"
#import "MopUtils.h"

@interface MopShareDelegate : NSObject<FATAppletMenuShareItemDelegate>
 
+ (instancetype)shareInstance;

@property (nonatomic, strong) UniModuleKeepAliveCallback shareCallback;

-(void) setShareAppMessage: (UniModuleKeepAliveCallback) shareCallback;

@end

#endif /* MopShareDelegate_h */
