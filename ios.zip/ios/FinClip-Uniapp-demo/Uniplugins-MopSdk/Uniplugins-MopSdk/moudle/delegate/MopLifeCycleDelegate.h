//
//  MopLifeCycleDelegate.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2022/11/4.
//  Copyright © 2022 DCloud. All rights reserved.
//

#ifndef MopLifeCycleDelegate_h
#define MopLifeCycleDelegate_h

#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>
#import "DCUniModule.h"
#import "MopSdkModule.h"

@interface MopLifeCycleDelegate : NSObject<FATAppletLifeCycleDelegate>
 
+ (instancetype)shareInstance;

@property (nonatomic, strong) UniModuleKeepAliveCallback onInitComplete;
@property (nonatomic, strong) UniModuleKeepAliveCallback onOpen;
@property (nonatomic, strong) UniModuleKeepAliveCallback onOpenFailure;
@property (nonatomic, strong) UniModuleKeepAliveCallback onInActive;
@property (nonatomic, strong) UniModuleKeepAliveCallback onActive;
@property (nonatomic, strong) UniModuleKeepAliveCallback onClose;
@property (nonatomic, strong) UniModuleKeepAliveCallback onDestroy;

@end


#endif /* MopLifeCycleDelegate_h */
