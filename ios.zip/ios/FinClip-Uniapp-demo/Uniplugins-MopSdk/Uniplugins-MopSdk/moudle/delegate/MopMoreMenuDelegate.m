//
//  MopMoreMenuDelegate.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/20.
//  Copyright © 2023 DCloud. All rights reserved.
//
//
#import "MopMoreMenuDelegate.h"

@implementation MopMoreMenuDelegate

static MopMoreMenuDelegate *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopMoreMenuDelegate alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

-(void) setRegisteredMoreMenuItems:(NSArray<id<FATAppletMenuProtocol>> *) menuItems onRegisteredMoreMenuItemClicked:(UniModuleKeepAliveCallback) onRegisteredMoreMenuItemClicked {
    self.menuItems = menuItems;
    self.onRegisteredMoreMenuItemClicked = onRegisteredMoreMenuItemClicked;
}

/**
 更多按钮中自定义的菜单，会在页面弹出菜单时调用该api
 @param appletInfo 小程序信息
 @param path 页面路径
 */
- (NSArray<id<FATAppletMenuProtocol>> *)customMenusInApplet:(FATAppletInfo *)appletInfo atPath:(NSString *)path{
    return self.menuItems;
}

/**
 点击自定义菜单时，会触发的事件（新版）
 只有实现了该代理方法，才会触发【-clickCustomItemMenuWithInfo:completion:】
 @param contentInfo 分享信息
 @param appletInfo 小程序信息
 @param completion 分享回调（小程序分享回调：1.【code】回调状态码；2.【result】回传给小程序的回调信息）
 */
- (void)clickCustomItemMenuWithInfo:(NSDictionary *)contentInfo inApplet:(FATAppletInfo *)appletInfo completion:(void (^)(FATExtensionCode code, NSDictionary *result))completion {
    if (self.onRegisteredMoreMenuItemClicked) {
        NSString *uuid = [MopCallbackUtils addCallback:completion];
        @try{
            self.onRegisteredMoreMenuItemClicked(@{@"uuid":uuid,@"appId":contentInfo[@"appId"],@"path":contentInfo[@"path"],@"menuItemId":contentInfo[@"menuId"],@"appInfo":[MopUtils appletToDictionary:appletInfo]
                                                 },YES);
        }@catch(NSException *error){
        }@finally {
            
        }
   }
}
 
@end
