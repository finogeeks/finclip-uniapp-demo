//
//  MopMoreMenuDelegate.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/20.
//  Copyright © 2023 DCloud. All rights reserved.
//
//
#import "MopMoreMenuDelegate.h"

@implementation MopMoreMenuDelegate

static MopMoreMenuDelegate *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopMoreMenuDelegate alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

-(void) setRegisteredMoreMenuItems:(NSArray<id<FATAppletMenuProtocol>> *) menuItems onRegisteredMoreMenuItemClicked:(UniModuleKeepAliveCallback) onRegisteredMoreMenuItemClicked {
    self.menuItems = menuItems;
    self.onRegisteredMoreMenuItemClicked = onRegisteredMoreMenuItemClicked;
}

-(void) setNavigationBarCloseButtonClicked:(UniModuleKeepAliveCallback) onCloseClicked {
    self.onCloseClicked = onCloseClicked;
}


- (NSArray<id<FATAppletMenuProtocol>> *)customMenusInApplet:(FATAppletInfo *)appletInfo atPath:(NSString *)path{
    return self.menuItems;
}

- (void)clickCustomItemMenuWithInfo:(NSDictionary *)contentInfo inApplet:(FATAppletInfo *)appletInfo completion:(void (^)(FATExtensionCode code, NSDictionary *result))completion {
    if (self.onRegisteredMoreMenuItemClicked) {
        NSString *uuid = [MopCallbackUtils addCallback:completion];
        @try{
            self.onRegisteredMoreMenuItemClicked(@{@"uuid":uuid,@"appId":contentInfo[@"appId"],@"path":contentInfo[@"path"],@"menuItemId":contentInfo[@"menuId"],@"appInfo":[MopUtils appletToDictionary:appletInfo]
                                                 },YES);
        }@catch(NSException *error){
        }@finally {
            
        }
   }
}

-(void)appletInfo:(FATAppletInfo *)appletInfo decideCloseWithDecisionHandler:(void(^)(BOOL allowClose))decisionHandler{
    if (self.onCloseClicked) {
        self.onCloseClicked(@{@"appId": appletInfo.appId}, YES);
    }
}
 
 
@end
