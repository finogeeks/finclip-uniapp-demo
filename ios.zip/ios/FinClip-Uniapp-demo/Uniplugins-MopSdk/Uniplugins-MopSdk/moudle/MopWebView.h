//
//  MopWebView.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//

#ifndef MopWebView_h
#define MopWebView_h

#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

#import "DCUniModule.h"

@interface MopWebView : NSObject
 
+ (instancetype)shareInstance;

- (void) getCurrentWebViewURL:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback) onProgress;

- (void) getCurrentWebViewUserAgent:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback) onProgress;

@end

#endif /* MopWebView_h */
