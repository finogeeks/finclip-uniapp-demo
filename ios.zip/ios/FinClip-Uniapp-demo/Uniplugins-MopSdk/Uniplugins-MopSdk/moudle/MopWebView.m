//
//  MopWebView.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//
#import "MopWebView.h"

@implementation MopWebView

static MopWebView *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MopWebView alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

- (void) getCurrentWebViewURL:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback) onProgress{
    @try {
        NSURL *url = [[FATClient sharedClient] getCurrentWebViewURL];
        if (onSuccess) onSuccess(@{@"url": url.path},YES);
    }@catch(NSException *error){
        if (onFail) onFail(nil, YES);
    }@finally {
        
    }
}

- (void) getCurrentWebViewUserAgent:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback) onProgress{
    [[FATClient sharedClient] getCurrentWebViewUserAgentWithCompletion:^(NSString *userAgent, NSError *error) {
        if (error) {
            if(onFail) onFail(@{@"code": [NSString stringWithFormat: @"%ld", error.code], @"message": error.description },YES);
        } else{
            if(onSuccess) onSuccess(@{@"userAgent": userAgent},YES);
        }
    }];
}

@end
