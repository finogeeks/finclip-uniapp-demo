//
//  MopUtils.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//

#import "MopUtils.h"

@implementation MopUtils

/**
 * 获取当前屏幕显示的viewcontroller
 **/
+ (UIViewController *)getCurrentVC
{
    UIViewController *rootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;

    UIViewController *currentVC = [MopUtils getCurrentVCFrom:rootViewController];
    
    return currentVC;
}

+ (UIViewController *)getCurrentVCFrom:(UIViewController *)rootVC
{
    UIViewController *currentVC;
    if ([rootVC presentedViewController]) {
        // 视图是被presented出来的
        rootVC = [rootVC presentedViewController];
    }
    if ([rootVC isKindOfClass:[UITabBarController class]]) {
        // 根视图为UITabBarController
        currentVC = [self getCurrentVCFrom:[(UITabBarController *)rootVC selectedViewController]];
    } else if ([rootVC isKindOfClass:[UINavigationController class]]){
        // 根视图为UINavigationController
        currentVC = [self getCurrentVCFrom:[(UINavigationController *)rootVC visibleViewController]];
    }
    else {
        // 根视图为非导航类
        currentVC = rootVC;
    }
    return currentVC;
}

/**
 *将16进制颜色转换为UIColor
 */
+ (UIColor*) colorWithARGB:(NSString *)color {
    NSString *cString = [[color stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
        
    // String should be 6 or 8 characters
    if ([cString length] < 8)
    {
        return [UIColor clearColor];
    }
        
    // 判断前缀
    if ([cString hasPrefix:@"0X"])
        cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"])
        cString = [cString substringFromIndex:1];
    if ([cString length] != 8)
        return [UIColor clearColor];


    // 从六位数值中找到RGB对应的位数并转换
    NSRange range;
    range.location = 0;
    range.length = 2;
    
    //A、 R、G、B
    unsigned int a, r, g, b;
    NSString *aString = [cString substringWithRange:range];
    range.location = 2;
    NSString *rString = [cString substringWithRange:range];
    range.location = 4;
    NSString *gString = [cString substringWithRange:range];
    range.location = 6;
    NSString *bString = [cString substringWithRange:range];
    [[NSScanner scannerWithString:aString] scanHexInt:&a];
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    return [UIColor colorWithRed: r/255.0f
                           green: g/255.0f
                           blue: b/255.0f
                           alpha: a/255.0f];
}

/**
 *判断字典的key值是否为空
 */
+ (BOOL)isNULL:(NSDictionary *)dict key:(NSString*)key {
    // judge nil
    if(![dict objectForKey:key]){
        return YES;
    }
    id obj = [dict objectForKey:key];// judge NSNull
    BOOL isNULL = [obj isEqual:[NSNull null]];
    return isNULL;
}

/**
 *判断字典的key值是否为空
 */
+ (NSMutableDictionary *) appletToDictionary:(FATAppletInfo *) appletInfo {
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    dic[@"appId"] = appletInfo.appId;
    dic[@"userId"] = appletInfo.userId;
    dic[@"currentUserId"] = appletInfo.currentUserId;
    dic[@"appAvatar"] = appletInfo.appAvatar;
    dic[@"appTag"] = appletInfo.appTag;
    dic[@"appTitle"] = appletInfo.appTitle;
    dic[@"coreDescription"] = appletInfo.coreDescription;
    dic[@"appDescription"] = appletInfo.appDescription;
    dic[@"appVersion"] = appletInfo.appVersion;
    dic[@"appVersionDescription"] = appletInfo.versionDescription;
    dic[@"sequence"] = appletInfo.sequence;
    dic[@"isGrayVersion"] = appletInfo.isGrayRelease ? @true : @false;
    dic[@"appThumbnail"] = appletInfo.appThumbnail;
    dic[@"groupId"] = appletInfo.groupId;
    dic[@"groupName"] = appletInfo.groupName;
    dic[@"appDescription"] = appletInfo.appDescription;
    dic[@"startParams"] = appletInfo.startParams;
    dic[@"cryptInfo"] = appletInfo.cryptInfo;
    dic[@"apiServer"] = appletInfo.apiServer;
    dic[@"wechatLoginInfo"] = appletInfo.wechatLoginInfo;
    dic[@"extInfo"] = appletInfo.extInfo;
    dic[@"qrCode"] = appletInfo.qrCode;
    dic[@"schemes"] = appletInfo.schemes;
    
    return dic;
}


@end


