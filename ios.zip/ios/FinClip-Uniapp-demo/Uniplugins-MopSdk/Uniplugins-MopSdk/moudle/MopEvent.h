//
//  MopEvent.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//

#ifndef MopEvent_h
#define MopEvent_h

#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

@interface MopEvent : NSObject
 
+ (instancetype)shareInstance;

- (void)sendCustomEvent:(NSString *) appId options:(NSDictionary *) options;

- (void)sendCustomEventToAll:(NSDictionary *) options;

@end

#endif /* MopEvent_h */
