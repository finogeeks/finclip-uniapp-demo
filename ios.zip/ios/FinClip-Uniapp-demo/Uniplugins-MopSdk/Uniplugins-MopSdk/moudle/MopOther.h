//
//  MopOther.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2023/11/17.
//  Copyright © 2023 DCloud. All rights reserved.
//

#ifndef MopOther_h
#define MopOther_h

#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

#import "DCUniModule.h"

@interface MopOther : NSObject
 
+ (instancetype)shareInstance;

- (void) setUserId:(NSString *) userId;

- (void) getFinFileAbsolutePath:(NSString *) appId finFile:(NSString *) finFile onCallback:(UniModuleKeepAliveCallback) onCallback;

@end

#endif /* MopOther_h */
