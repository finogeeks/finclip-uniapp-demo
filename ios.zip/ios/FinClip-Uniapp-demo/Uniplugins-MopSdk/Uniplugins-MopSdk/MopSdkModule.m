//
//  TestModule.m
//  DCTestUniPlugin
//
//  Created by XHY on 2020/4/22.
//  Copyright © 2020 DCloud. All rights reserved.
//
#import "MopSdkModule.h"

@implementation MopSdkModule

//**================小程序SDK初始化=======================**
//初始化SDK
UNI_EXPORT_METHOD(@selector(initialize:success:fail:))
- (void)initialize:(NSDictionary *)config success:(UniModuleKeepAliveCallback)success fail:(UniModuleKeepAliveCallback)fail {
    BOOL isYES = [[MopInit shareInstance]init:config success:success fail:fail];
    if (isYES) {
        [[MopDelegate shareInstance] initDelegate];
    }
}

//**================小程序管理=======================**
//设置生命周期
UNI_EXPORT_METHOD(@selector(setAppletLifecycleCallback:onOpen:onOpenFailure:onInActive:onActive:onClose:onDestroy:))
- (void)setAppletLifecycleCallback:(UniModuleKeepAliveCallback)onInitComplete onOpen:(UniModuleKeepAliveCallback)onOpen
    onOpenFailure:(UniModuleKeepAliveCallback)onOpenFailure
    onInActive:(UniModuleKeepAliveCallback)onInActive
    onActive:(UniModuleKeepAliveCallback)onActive
    onClose:(UniModuleKeepAliveCallback)onClose
    onDestroy:(UniModuleKeepAliveCallback)onDestroy {
    [[MopApplet shareInstance]setAppletLifecycleCallback:onInitComplete onOpen:onOpen onOpenFailure:onOpenFailure onInActive:onInActive onActive:onActive onClose:onClose onDestroy:onDestroy];
}
// 打开小程序
UNI_EXPORT_METHOD(@selector(openApplet:onSuccess:onFail:onProgress:))
- (void)openApplet:(NSDictionary *)options onSuccess:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback)onProgress{
    [[MopApplet shareInstance]openApplet:options onSuccess:onSuccess onFail:onFail onProgress:onProgress];
}
//二维码打开小程序
UNI_EXPORT_METHOD(@selector(openAppletByQrcode:onSuccess:onFail:onProgress:))
- (void)openAppletByQrcode:(NSDictionary *)options onSuccess:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback)onProgress{
    [[MopApplet shareInstance]openAppletByQrcode:options onSuccess:onSuccess onFail:onFail onProgress:onProgress];
}
//搜索小程序
UNI_EXPORT_METHOD(@selector(searchApplets:onSuccess:onFail:onProgress:))
- (void)searchApplets:(NSDictionary *)options onSuccess:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback)onProgress{
    [[MopApplet shareInstance]searchApplets:options onSuccess:onSuccess onFail:onFail onProgress:onProgress];
}
//批量下载小程序
UNI_EXPORT_METHOD(@selector(downloadApplets:onSuccess:onFail:))
- (void) downloadApplets: (NSDictionary *) options onSuccess:(UniModuleKeepAliveCallback) onSuccess
    onFail:(UniModuleKeepAliveCallback)  onFail {
    [[MopApplet shareInstance]downloadApplets:options onSuccess:onSuccess onFail:onFail];
}
//获取小程序页面截图
UNI_EXPORT_METHOD(@selector(captureAppletPicture:snapShotWholePage:onSuccess:onFail:))
- (void) captureAppletPicture: (NSString *) appId
                    snapShotWholePage:(BOOL *) snapShotWholePage
                    onSuccess:(UniModuleKeepAliveCallback) onSuccess
                    onFail:(UniModuleKeepAliveCallback)  onFail {
    [[MopApplet shareInstance]captureAppletPicture:appId snapShotWholePage:snapShotWholePage onSuccess:onSuccess onFail:onFail];
}
//将小程序移至前端
UNI_EXPORT_METHOD(@selector(moveMiniProgramToFront:))
- (void) moveMiniProgramToFront:(NSString *) appId {
    [[MopApplet shareInstance]moveMiniProgramToFront:appId];
}
//将APP移至前端
UNI_EXPORT_METHOD(@selector(moveAppToFront))
- (void) moveAppToFront {
    [[MopApplet shareInstance]moveAppToFront];
}
//当前小程序appId
UNI_EXPORT_METHOD(@selector(currentAppletId:))
-(void) currentAppletId:(UniModuleKeepAliveCallback) onCallback {
    [[MopApplet shareInstance]currentAppletId:onCallback];
}
//当前小程序信息
UNI_EXPORT_METHOD(@selector(currentApplet:))
- (void) currentApplet: (UniModuleKeepAliveCallback) onCallback {
    [[MopApplet shareInstance]currentApplet:onCallback];
}
// 获取使用过的指定小程序信息
UNI_EXPORT_METHOD(@selector(getUsedApplet:onCallback:))
- (void) getUsedApplet:(NSString *) appId onCallback:(UniModuleKeepAliveCallback) onCallback{
    [[MopApplet shareInstance]getUsedApplet:appId onCallback:onCallback];
}
// 获取使用过的小程序列表信息
UNI_EXPORT_METHOD(@selector(getUsedApplets:))
- (void) getUsedApplets: (UniModuleKeepAliveCallback) onCallback{
    [[MopApplet shareInstance]getUsedApplets:onCallback];
}
// 判断是否使用过小程序
UNI_EXPORT_METHOD(@selector(isUsedApplet:onCallback:))
- (void) isUsedApplet:(NSString *) appId onCallback:(UniModuleKeepAliveCallback) onCallback{
    [[MopApplet shareInstance]isUsedApplet:appId onCallback:onCallback];
      // this.mopApplet.getUsedApplet(appId,onCallback);
}
//关闭小程序
UNI_EXPORT_METHOD(@selector(closeApplet:))
- (void)closeApplet:(NSString *)appId{
    [[MopApplet shareInstance]closeApplet:appId];
}
//关闭所有小程序信息
UNI_EXPORT_METHOD(@selector(closeApplets))
- (void)closeApplets{
    [[MopApplet shareInstance]closeApplets];
}
//清除内存指定小程序
UNI_EXPORT_METHOD(@selector(finishRunningApplet:))
- (void)finishRunningApplet:(NSString *)appId{
    [[MopApplet shareInstance]finishRunningApplet:appId];
}
//清队内存所有小程序信息
UNI_EXPORT_METHOD(@selector(finishRunningApplets))
- (void)finishRunningApplets{
    [[MopApplet shareInstance]finishRunningApplets];
}
//清除本地指定小程序信息
UNI_EXPORT_METHOD(@selector(clearApplet:))
- (void)clearApplet:(NSString *) appId{
    [[MopApplet shareInstance]clearApplet:appId];
}
//清除本地所有小程序信息
UNI_EXPORT_METHOD(@selector(clearApplets))
- (void)clearApplets{
    [[MopApplet shareInstance]clearApplets];
}

//**================小程序自定义API管理=======================**
//注册小程序API
UNI_EXPORT_METHOD(@selector(registerExtensionApi:callback:))
- (void)registerExtensionApi:(NSString *) name callback:(UniModuleKeepAliveCallback)callback{
    [[MopExtension shareInstance] registerExtensionApi:name callback:callback];
}
//取消注册小程序API
UNI_EXPORT_METHOD(@selector(unRegisterExtensionApi:))
- (void)unRegisterExtensionApi:(NSString *) name{
    [[MopExtension shareInstance] unRegisterExtensionApi:name];
}
//注册小程序webView API
UNI_EXPORT_METHOD(@selector(registerWebExtensionApi:callback:))
- (void)registerWebExtensionApi:(NSString *) name callback:(UniModuleKeepAliveCallback)callback{
    [[MopExtension shareInstance] registerWebExtensionApi:name callback:callback];
}
//取消注册小程序webView API
UNI_EXPORT_METHOD(@selector(unRegisterWebExtensionApi:))
- (void)unRegisterWebExtensionApi:(NSString *) name{
    [[MopExtension shareInstance] unRegisterWebExtensionApi:name];
}
//成功回调小程序API
UNI_EXPORT_METHOD(@selector(onSuccess:options:));
- (void)onSuccess:(NSString *) uuid options:(NSDictionary *)options{
    [[MopExtension shareInstance] onSuccess:uuid options:options];
}
//失败回调小程序API
UNI_EXPORT_METHOD(@selector(onFail:options:));
- (void)onFail:(NSString *) uuid options:(NSDictionary *)options{
    [[MopExtension shareInstance] onFail:uuid options:options];
}

//**================小程序代理管理=======================**
//设置获取头像
UNI_EXPORT_METHOD(@selector(setChooseAvatar:))
-(void) setChooseAvatar:(NSString *) avatarUrl{
    [[MopDelegate shareInstance] setChooseAvatar:avatarUrl];
}
// 设置用户信息
UNI_EXPORT_METHOD(@selector(setUserInfo:))
-(void) setUserInfo:(NSDictionary *) options{
    [[MopDelegate shareInstance] setUserInfo:options];
}
//设置获取手机
UNI_EXPORT_METHOD(@selector(setPhoneNumber:))
-(void) setPhoneNumber:(NSString *) phoneNumber{
    [[MopDelegate shareInstance] setPhoneNumber:phoneNumber];
}
//设置按钮分享代理
UNI_EXPORT_METHOD(@selector(setOpenTypeShareAppMessage:))
-(void) setOpenTypeShareAppMessage:(UniModuleKeepAliveCallback) shareCallback{
    [[MopDelegate shareInstance]setOpenTypeShareAppMessage:shareCallback];
}
//设置菜单分享代理
UNI_EXPORT_METHOD(@selector(setShareAppMessage:))
-(void) setShareAppMessage:(UniModuleKeepAliveCallback) shareCallback{
    [[MopDelegate shareInstance]setShareAppMessage:shareCallback];
}
//设置菜单
UNI_EXPORT_METHOD(@selector(setRegisteredMoreMenuItems:onRegisteredMoreMenuItemClicked:))
-(void) setRegisteredMoreMenuItems:(NSArray *) options onRegisteredMoreMenuItemClicked:(UniModuleKeepAliveCallback) onRegisteredMoreMenuItemClicked{
    [[MopDelegate shareInstance]setRegisteredMoreMenuItems:options onRegisteredMoreMenuItemClicked:onRegisteredMoreMenuItemClicked];
}
//设置灰度发布
UNI_EXPORT_METHOD(@selector(setGrayAppletVersionConfigs:))
-(void) setGrayAppletVersionConfigs:(NSArray *)options {
    [[MopDelegate shareInstance]setGrayAppletVersionConfigs:options];
}

//**================小程序WebView管理=======================**
//获取当前小程序webView的URL
UNI_EXPORT_METHOD(@selector(getCurrentWebViewURL:onFail:onProgress:))
- (void) getCurrentWebViewURL:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback) onProgress {
    [[MopWebView shareInstance] getCurrentWebViewURL:onSuccess onFail:onFail onProgress:onProgress];
}
// 获取当前小程序webView的userAgent
UNI_EXPORT_METHOD(@selector(getCurrentWebViewUserAgent:onFail:onProgress:))
- (void) getCurrentWebViewUserAgent:(UniModuleKeepAliveCallback) onSuccess onFail:(UniModuleKeepAliveCallback) onFail onProgress:(UniModuleKeepAliveCallback) onProgress {
    [[MopWebView shareInstance] getCurrentWebViewUserAgent:onSuccess onFail:onFail onProgress:onProgress];
}
//设置webView的指定url的cookies
UNI_EXPORT_METHOD(@selector(setWebViewCookie:))
- (void) setWebViewCookie:(NSDictionary *) options {
}
// 删除webView的指定url的cookies
UNI_EXPORT_METHOD(@selector(removeWebViewCookie:))
- (void) removeWebViewCookie:(NSDictionary *) options{
}
// 删除webView的所有cookies
UNI_EXPORT_METHOD(@selector(removeWebViewAllCookie:))
- (void) removeWebViewAllCookie:(NSDictionary *) options{
}

//**================小程序事件管理=======================**
// 原生发送事件给小程序
UNI_EXPORT_METHOD(@selector(sendCustomEvent:options:))
- (void)sendCustomEvent:(NSString *) appId options:(NSDictionary *) options{
    [[MopEvent shareInstance]sendCustomEvent:appId options:options];
}
// 原生发送事件给小程序
UNI_EXPORT_METHOD(@selector(sendCustomEventToAll:))
- (void)sendCustomEventToAll:(NSDictionary *) options{
    [[MopEvent shareInstance]sendCustomEventToAll:options];
}

//**================小程序其它管理=======================**
//设置userId
UNI_EXPORT_METHOD(@selector(setUserId:));
- (void) setUserId:(NSString *) userId {
    [[MopOther shareInstance] setUserId:userId];
}
// 转换小程序文件路径为绝对路径
UNI_EXPORT_METHOD(@selector(getFinFileAbsolutePath:finFile:onCallback:));
- (void) getFinFileAbsolutePath:(NSString *) appId finFile:(NSString *) finFile onCallback:(UniModuleKeepAliveCallback) onCallback{
    [[MopOther shareInstance] getFinFileAbsolutePath:appId finFile:finFile onCallback:onCallback];
}

//**================小程序扩展SDK管理=======================**
//注册扩展SDK
UNI_EXPORT_METHOD(@selector(registerExtSDK));
- (void) registerExtSDK {
    @try {
        Class class = NSClassFromString(@"FATExtClient");
        if (class && [class respondsToSelector:@selector(sharedClient)]){
            id instance = [class sharedClient];
            SEL selector = NSSelectorFromString(@"fat_prepareExtensionApis");
            if ([instance respondsToSelector:selector]){
                IMP imp = [instance methodForSelector:selector];
                void (*func)(id, SEL) = (void *)imp;
                func(instance, selector);
            }
        }
    }@catch(NSException *error){
    }@finally {
    }
}
//注册百度SDK
UNI_EXPORT_METHOD(@selector(registerBDMapSDK:));
- (void) registerBDMapSDK:(NSString *) key {
    @try {
        Class class = NSClassFromString(@"FATBDMapComponent");
        if (class){
            SEL selector = NSSelectorFromString(@"setBDMapAppKey");
            if ([class respondsToSelector:selector]){
                IMP imp = [class methodForSelector:selector];
                void (*func)(id, SEL, NSString *) = (void *)imp;
                func(class, selector, key);
            }
        }
    }@catch(NSException *error){
    }@finally {
    }
}
//注册高德SDK
UNI_EXPORT_METHOD(@selector(registerGDMapSDK:));
- (void) registerGDMapSDK:(NSString *) key {
    @try {
        Class class = NSClassFromString(@"FATGDMapComponent");
        if (class){
            SEL selector = NSSelectorFromString(@"setGDMapAppKey");
            if ([class respondsToSelector:selector]){
                IMP imp = [class methodForSelector:selector];
                void (*func)(id, SEL, NSString *) = (void *)imp;
                func(class, selector, key);
            }
        }
    }@catch(NSException *error){
    }@finally {
    }
}
//注册腾讯SDK
UNI_EXPORT_METHOD(@selector(registerTXMapSDK:));
- (void) registerTXMapSDK:(NSString *) key {
    @try {
        Class class = NSClassFromString(@"FATTXMapComponent");
        if (class){
            SEL selector = NSSelectorFromString(@"setTXMapAppKey");
            if ([class respondsToSelector:selector]){
                IMP imp = [class methodForSelector:selector];
                void (*func)(id, SEL, NSString *) = (void *)imp;
                func(class, selector, key);
            }
        }
    }@catch(NSException *error){
    }@finally {
    }
}
//注册蓝牙SDK
UNI_EXPORT_METHOD(@selector(registerBluetoothSDK));
- (void) registerBluetoothSDK {
    @try {
        Class class = NSClassFromString(@"FATContactComponent");
        if (class){
            SEL selector = NSSelectorFromString(@"registerComponent");
            if ([class respondsToSelector:selector]){
                IMP imp = [class methodForSelector:selector];
                void (*func)(id, SEL) = (void *)imp;
                func(class, selector);
            }
        }
    }@catch(NSException *error){
    }@finally {
    }
}
//注册联系人SDK
UNI_EXPORT_METHOD(@selector(registerContactSDK));
- (void) registerContactSDK {
    @try {
        Class class = NSClassFromString(@"FATContactComponent");
        if (class){
            SEL selector = NSSelectorFromString(@"registerComponent");
            if ([class respondsToSelector:selector]){
                IMP imp = [class methodForSelector:selector];
                void (*func)(id, SEL) = (void *)imp;
                func(class, selector);
            }
        }
    }@catch(NSException *error){
    }@finally {
    }
}
//注册剪贴板SDK
UNI_EXPORT_METHOD(@selector(registerClipboardSDK));
- (void) registerClipboardSDK {
    @try {
        Class class = NSClassFromString(@"FATClipBoardComponent");
        if (class){
            SEL selector = NSSelectorFromString(@"registerComponent");
            if ([class respondsToSelector:selector]){
                IMP imp = [class methodForSelector:selector];
                void (*func)(id, SEL) = (void *)imp;
                func(class, selector);
            }
        }
    }@catch(NSException *error){
    }@finally {
    }
}
//注册直播SDK
UNI_EXPORT_METHOD(@selector(registerLiveSDK));
- (void) registerLiveSDK {
    @try {
        // 直播初始化
        #ifdef __arm64__
            Class class = NSClassFromString(@"FATLiveComponent");
            if (class){
                SEL selector = NSSelectorFromString(@"registerComponent");
                if ([class respondsToSelector:selector]){
                    IMP imp = [class methodForSelector:selector];
                    void (*func)(id, SEL) = (void *)imp;
                    func(class, selector);
                }
            }
        #endif
    }@catch(NSException *error){
    }@finally {
    }
}
//注册日历SDK
UNI_EXPORT_METHOD(@selector(registerCalendarSDK));
- (void) registerCalendarSDK {
}

@end
