//
//  FATClientHelper.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2022/4/30.
//  Copyright © 2022 DCloud. All rights reserved.
//

#import "FATClientHelper.h"
#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

@implementation FATClientHelper

static FATClientHelper *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
       dispatch_once(&onceToken, ^{
           instance = [[FATClientHelper alloc] init];
       });
       return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}

#pragma mark - FATAppletDelegate

//- (void)contactWithAppletInfo:(FATAppletInfo *)appletInfo sessionFrom:(NSString *)sessionFrom sendMessageTitle:(NSString *)sendMessageTitle sendMessagePath:(NSString *)sendMessagePath sendMessageImg:(NSString *)sendMessageImg showMessageCard:(BOOL)showMessageCard
//{
//
//}

//- (void)applet:(FATAppletInfo *)appletInfo didClickMoreBtnAtPath:(NSString *)path
//{
//
//}


//- (void)launchAppWithAppletInfo:(FATAppletInfo *)appletInfo appParameter:(NSString *)appParameter bindError:(void (^)(NSDictionary *result))bindError bindLaunchApp:(void (^)(NSDictionary *result))bindLaunchApp
//{
//
//}
//
//- (void)feedbackWithAppletInfo:(FATAppletInfo *)appletInfo
//{
//
//}

//- (void)forwardAppletWithInfo:(NSDictionary *)contentInfo completion:(void (^)(FATExtensionCode, NSDictionary *))completion
//{
//    NSLog(@"小程序信息:%@", contentInfo);
//
//    // 1.如果你需要将小程序转发到自己app的聊天室，那么就根据contentInfo封装成自己IM消息，然后发送。
//
//    // 2.如果你需要将小程序转发到自己app的朋友圈，那么就根据contentInfo，组装信息发送给后台。
//}

- (NSDictionary *)grayExtensionWithAppletId:(NSString *)appletId
{
    return self.grayAppletVersionConfigs;
}

- (NSDictionary *)getUserInfoWithAppletInfo:(FATAppletInfo *)appletInfo
{
    return self.userInfo;
}

- (void)getPhoneNumberWithAppletInfo:(FATAppletInfo *)appletInfo bindGetPhoneNumber:(void (^)(NSDictionary *result))bindGetPhoneNumber
{
    if (self.phoneNumber) {
        NSDictionary *result = [NSDictionary dictionaryWithObject:self.phoneNumber forKey:@"phoneNumber"];
        bindGetPhoneNumber(result);
        
    }
}

- (void)chooseAvatarWithAppletInfo:(FATAppletInfo *)appletInfo bindChooseAvatar:(void (^)(NSDictionary *result))bindChooseAvatar
{
    if (self.avatarUrl) {
        NSDictionary *result = [NSDictionary dictionaryWithObject:self.avatarUrl forKey:@"avatarUrl"];
        bindChooseAvatar(result);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didOpenCompletion:(NSError *)error{
    if (self.onCloseButtonClicked) {
        self.onCloseButtonClicked(appletInfo.appId,YES);
    }
    if (self.onStart) {
        self.onStart(@{@"appid":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didCloseCompletion:(NSError *)error
{
    if (self.onCloseButtonClicked) {
        self.onCloseButtonClicked(appletInfo.appId,YES);
    }
    if (self.onStop) {
        self.onStop(@{@"appid":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo initCompletion:(NSError *)error
{
    if (self.onInitComplete) {
        self.onInitComplete(@{@"appid":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didActive:(NSError *)error
{
    if (self.onResume) {
        self.onResume(@{@"appid":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo resignActive:(NSError *)error
{
    if (self.onPause) {
        self.onPause(@{@"appid":appletInfo.appId},YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo didFail:(NSError *)error
{
    if (self.onFailure) {
        self.onFailure(@{@"appid":appletInfo.appId,@"code":[NSString stringWithFormat: @"%ld", error.code] },YES);
    }
}

- (void)appletInfo:(FATAppletInfo *)appletInfo dealloc:(NSError *)error
{
    if (self.onDestroy) {
        self.onDestroy(@{@"appid":appletInfo.appId },YES);
    }
}


- (NSArray<id<FATAppletMenuProtocol>> *)customMenusInApplet:(FATAppletInfo *)appletInfo atPath:(NSString *)path
{
    return self.registeredMoreMenuItems;
}

- (void)clickCustomItemMenuWithInfo:(NSDictionary *)contentInfo inApplet:(FATAppletInfo *)appletInfo completion:(void (^)(FATExtensionCode code, NSDictionary *result))completion
{
    if (self.onRegisteredMoreMenuItemClicked) {
        [[self mopSdkModule] addExtenssionApiCallback:completion];
        
        self.onRegisteredMoreMenuItemClicked(@{@"appId": [appletInfo appId],
                                               @"path": contentInfo[@"path"],
                                               @"menuItemId": contentInfo[@"menuId"],
                                               @"appInfo": contentInfo
                                             }, YES);
    }
}
@end

