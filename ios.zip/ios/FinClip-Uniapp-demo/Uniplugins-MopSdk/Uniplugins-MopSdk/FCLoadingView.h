//
//  FCLoadingView.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2022/11/4.
//  Copyright © 2022 DCloud. All rights reserved.
//

#ifndef FCLoadingView_h
#define FCLoadingView_h
#import <FinApplet/FinApplet.h>
 
@interface FCLoadingView : FATBaseLoadingView
 
@end

#endif /* FCLoadingView_h */
