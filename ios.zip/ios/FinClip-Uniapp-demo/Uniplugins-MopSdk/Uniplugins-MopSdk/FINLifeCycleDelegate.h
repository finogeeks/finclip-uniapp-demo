//
//  FINLifeCycleDelegate.h
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2022/11/4.
//  Copyright © 2022 DCloud. All rights reserved.
//

#ifndef FINLifeCycleDelegate_h
#define FINLifeCycleDelegate_h

#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>
#import "DCUniModule.h"
#import "MopSdkModule.h"

@interface FINLifeCycleDelegate : NSObject<FATAppletLifeCycleDelegate>
 
+ (instancetype)shareInstance;

@property (nonatomic, strong) UniModuleKeepAliveCallback onInitComplete;
@property (nonatomic, strong) UniModuleKeepAliveCallback onFailure;
@property (nonatomic, strong) UniModuleKeepAliveCallback onCreate;
@property (nonatomic, strong) UniModuleKeepAliveCallback onStart;
@property (nonatomic, strong) UniModuleKeepAliveCallback onResume;
@property (nonatomic, strong) UniModuleKeepAliveCallback onPause;
@property (nonatomic, strong) UniModuleKeepAliveCallback onStop;
@property (nonatomic, strong) UniModuleKeepAliveCallback onDestroy;

@property (nonatomic, strong) UniModuleKeepAliveCallback onCloseButtonClicked;

@end


#endif /* FINLifeCycleDelegate_h */
