//
//  FCLoadingView.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2022/11/4.
//  Copyright © 2022 DCloud. All rights reserved.
//

#import "FCLoadingView.h"
 
@implementation FCLoadingView
 
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.bottomImageView.hidden = YES;
    }
    return self;
}
 
@end
