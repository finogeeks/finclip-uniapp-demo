//
//  FINButtonDelegate.m
//  Uniplugins-MopSdk
//
//  Created by 杨彬 on 2022/11/4.
//  Copyright © 2022 DCloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FINButtonDelegate.h"
#import <Foundation/Foundation.h>
#import <FinApplet/FinApplet.h>

@implementation FINButtonDelegate

static FINButtonDelegate *instance = nil;

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[FINButtonDelegate alloc] init];
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copy {
    return instance;
}



-(BOOL)getUserInfoWithAppletInfo:(FATAppletInfo *)appletInfo bindGetUserInfo:(void (^)(NSDictionary *result))bindGetUserInfo{
    if (self.userInfo) {
        bindGetUserInfo(self.userInfo);
    }
    return YES;
}

-(BOOL)getPhoneNumberWithAppletInfo:(FATAppletInfo *)appletInfo bindGetPhoneNumber:(void (^)(NSDictionary *result))bindGetPhoneNumber
{
    if (self.phoneNumber) {
        NSDictionary *result = [NSDictionary dictionaryWithObject:self.phoneNumber forKey:@"phoneNumber"];
        bindGetPhoneNumber(result);
    }
    return YES;
}

-(BOOL)chooseAvatarWithAppletInfo:(FATAppletInfo *)appletInfo bindChooseAvatar:(void (^)(NSDictionary *result))bindChooseAvatar
{
    if (self.avatarUrl) {
        NSDictionary *result = [NSDictionary dictionaryWithObject:self.avatarUrl forKey:@"avatarUrl"];
        bindChooseAvatar(result);
    }
    return YES;
}

@end
