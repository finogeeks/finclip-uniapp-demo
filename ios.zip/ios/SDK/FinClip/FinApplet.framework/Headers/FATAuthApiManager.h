//
//  FATAuthApiManager.h
//  FinApplet
//  权限相关的公共api方法
//  Created by 滔 on 2023/4/4.
//  Copyright © 2023 finogeeks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "IFATAuthApiManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface FATAuthApiManager : NSObject<IFATAuthApiManager>

@end

NS_ASSUME_NONNULL_END
