//
//  FinAppletExtension.h
//  FinAppletExtension
//
//  Created by Haley on 2020/08/11.
//  Copyright © 2019 finogeeks. All rights reserved.
//

// In this header, you should import all the public headers of your framework using statements like #import <FinAppletExt/FinAppletExt.h>

#import "FATExtClient.h"
